/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * --------------------
 * ListReadHandler.java
 * --------------------
 * (C)opyright 2003, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: ListReadHandler.java,v 1.6 2004/01/01 23:59:26 mungady Exp $
 *
 * Changes
 * -------
 * 12-Nov-2003 : Initial version (TM);
 *  
 */

package org.jfree.xml.parser.coretypes;

import java.util.ArrayList;
import java.util.List;
import java.util.LinkedList;
import java.util.Vector;
import java.util.Stack;

import org.jfree.xml.parser.AbstractXmlReadHandler;
import org.jfree.xml.parser.XmlReadHandler;
import org.jfree.xml.parser.XmlReaderException;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;

/**
 * A SAX handler for reading a list from an XML element.
 */
public class ListReadHandler extends AbstractXmlReadHandler {

    private List retval;
    private ArrayList handlers;
    private String type;

    public ListReadHandler() {
    }

    protected void startParsing(Attributes attrs) throws SAXException {
        type = attrs.getValue("type");
        if (type == null) {
            type = "array-list";
        }
        handlers = new ArrayList();
    }

    protected XmlReadHandler getHandlerForChild(String tagName, Attributes atts)
        throws XmlReaderException, SAXException {
        XmlReadHandler handler = getRootHandler().createHandler(Object.class, tagName, atts);
        handlers.add(handler);
        return handler;
    }

    protected void doneParsing() throws SAXException, XmlReaderException {
        XmlReadHandler[] handler = (XmlReadHandler[])
            handlers.toArray(new XmlReadHandler[handlers.size()]);
        retval = createList(handler.length);
        for (int i = 0; i < handler.length; i++) {
            retval.add(handler[i].getObject());
        }
        handlers.clear();
    }

    private List createList(int initialSize) {
        if (type.equals("stack")) {
            return new Stack();
        }
        if (type.equals("linked-list")) {
            return new LinkedList();
        }
        if (type.equals("vector")) {
            return new Vector(initialSize);
        }
        return new ArrayList(initialSize);
    }

    /**
     * Returns the object under construction.
     * 
     */
    public Object getObject() {
        return retval;
    }
    
}
