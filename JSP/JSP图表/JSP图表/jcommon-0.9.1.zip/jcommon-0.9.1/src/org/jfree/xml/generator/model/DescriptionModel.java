/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ---------------------
 * DescriptionModel.java
 * ---------------------
 * (C)opyright 2003, 2004, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: DescriptionModel.java,v 1.8 2004/01/01 23:59:31 mungady Exp $
 *
 * Changes
 * -------
 * 21-Jun-2003 : Initial version (TM);
 *
 */

package org.jfree.xml.generator.model;

import java.util.HashMap;
import java.util.ArrayList;


import org.jfree.util.Log;

/**
 * A model containing class descriptions.
 */
public class DescriptionModel {

    private ArrayList sources;
    /** The classes. */
    private ArrayList classes;

    /** Maps classes to class descriptions. */
    private HashMap classesMap;
    
    /** The mapping model. */
    private MappingModel mappingModel;
    private Comments modelComments;
    private HashMap includeComments;

    /**
     * Creates a new class description model.
     */
    public DescriptionModel() {
        classes = new ArrayList();
        classesMap = new HashMap();
        mappingModel = new MappingModel();
        sources = new ArrayList();
        includeComments = new HashMap();
    }

    /**
     * Adds a class description to the model.
     * 
     * @param cd  the class description.
     */
    public void addClassDescription(ClassDescription cd) {
        classesMap.put(cd.getObjectClass(), cd);
        if (classes.contains(cd) == false) {
            classes.add(cd);
        }
    }

    /**
     * Removes a class description from the model.
     * 
     * @param cd  the class description.
     */
    public void removeClassDescription(ClassDescription cd) {
        this.classesMap.remove(cd.getObjectClass());
        this.classes.remove(cd);
    }

    /**
     * Returns a class description.
     * 
     * @param index  the description index (zero-based).
     * 
     * @return a class description.
     */
    public ClassDescription get(int index) {
        return (ClassDescription) this.classes.get(index);
    }

    /**
     * Returns a class description for the given class name.
     * 
     * @param key  the class name.
     * 
     * @return the class description.
     */
    public ClassDescription get(Class key) {
        return (ClassDescription) this.classesMap.get(key);
    }

    /**
     * Returns the number of classes in the model.
     * 
     * @return the number of classes in the model.
     */
    public int size() {
        return this.classes.size();
    }

    /**
     * Returns the mapping model.
     * 
     * @return the mapping model.
     */
    public MappingModel getMappingModel() {
        return this.mappingModel;
    }

    public void addSource(String source) {
        sources.add(source);
    }

    public String[] getSources() {
        return (String[]) sources.toArray(new String[sources.size()]);
    }

    public void prune() {
        ClassDescription[] cds = (ClassDescription[])
            classes.toArray(new ClassDescription[0]);
        for (int i = 0; i < cds.length; i++) {
            if (cds[i].isUndefined()) {
                removeClassDescription(cds[i]);
                Log.debug("Pruned: " + cds[i].getName());
            }
        }
    }

    public void addIncludeComment(String source, Comments comments) {
        includeComments.put(source, comments);
    }

    public Comments getIncludeComment(String source) {
        return (Comments) includeComments.get(source);
    }

    public Comments getModelComments() {
        return modelComments;
    }

    public void setModelComments(Comments modelComments) {
        Log.debug ("Model: Comment set: " + modelComments);
        this.modelComments = modelComments;
    }
}
