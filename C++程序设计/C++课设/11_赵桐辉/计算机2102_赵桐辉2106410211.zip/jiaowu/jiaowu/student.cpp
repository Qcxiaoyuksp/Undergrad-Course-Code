#include <string>
#include <fstream>
#include <iostream>
#include "student.h"
using namespace std;

//���캯�� 
student::student()
{
	studentNumber = "";
	majorAndClass = "";
}
//����ѧ��������Ϣ
void student::setStudentBasicInfo(string new_studentNumber, string new_name, string new_sex, string new_majorAndClass, string new_birth, string new_politicStatus, string new_address)
{
	studentNumber = new_studentNumber;
	name = new_name;
	sex = new_sex;
	majorAndClass = new_majorAndClass;
	birth = new_birth;
	politicStatus = new_politicStatus;
	address = new_address;
}
//��ѯ������Ϣ
void student::searchBasicInfo() const
{
	cout << endl << "\tѧ�ţ�" << studentNumber << "  " << "������" << name << "  " << "�Ա�" << sex << "  " << "רҵ�༶��" << majorAndClass << "  " << "���գ�" << birth << "  " << "������ò��" << politicStatus << "  " << "��ͥ��ַ��" << address << endl;
}
//����ѧ��
string student::getStudentNumber() const
{
	return studentNumber;
}
//�������� 
string student::getName()
{
	return name;
}
//���ļ���д������ 
void student::writeToTxtFileS() const
{
	ofstream txtOut("studentBasicInfo.txt", ios::app);

	txtOut << studentNumber << "  " << password << "  " << name << "  " << sex << "  " << majorAndClass << "  " << birth << "  " << politicStatus << "  " << address << endl;

	txtOut.close();
}
//���ļ��ж�ȡ���� 
void student::readFromTxtFileS(int num)
{
	fstream txtIn("studentBasicInfo.txt", ios::in);
	string temp;
	int line = 1;
	if (num == 1)
		txtIn >> studentNumber >> password >> name >> sex >> majorAndClass >> birth >> politicStatus >> address;
	else
	{
		while (getline(txtIn, temp, '\n'))
		{
			line++;
			if (line == num)
				txtIn >> studentNumber >> password >> name >> sex >> majorAndClass >> birth >> politicStatus >> address;
		}

	}
	txtIn.close();
}

