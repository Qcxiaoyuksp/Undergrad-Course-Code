/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * -----------------
 * MappingModel.java
 * -----------------
 * (C)opyright 2003, 2004, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: MappingModel.java,v 1.3 2004/01/01 23:59:31 mungady Exp $
 *
 * Changes 
 * -------------------------
 * 20.11.2003 : Initial version
 *  
 */

package org.jfree.xml.generator.model;

import java.util.HashMap;
import java.util.ArrayList;

import org.jfree.util.Log;

public class MappingModel {
    private HashMap mappingInfos;
    private ArrayList manualMappings;
    private ArrayList multiplexMappings;


    public MappingModel() {
        mappingInfos = new HashMap();
        manualMappings = new ArrayList();
        multiplexMappings = new ArrayList();
    }

    public MultiplexMappingInfo[] getMultiplexMapping() {
        return (MultiplexMappingInfo[]) multiplexMappings.toArray
            (new MultiplexMappingInfo[multiplexMappings.size()]);
    }

    public ManualMappingInfo[] getManualMapping() {
        return (ManualMappingInfo[]) manualMappings.toArray
            (new ManualMappingInfo[manualMappings.size()]);
    }

    public void addManualMapping(ManualMappingInfo mappingInfo) {
        if (mappingInfos.containsKey(mappingInfo.getBaseClass()) == false)
        {
            manualMappings.add(mappingInfo);
            mappingInfos.put(mappingInfo.getBaseClass(), mappingInfo);
        }
        else
        {
            Object o = mappingInfos.get(mappingInfo.getBaseClass());
            if (o instanceof ManualMappingInfo)
            {
                Log.info ("Duplicate manual mapping: " + mappingInfo.getBaseClass());
            }
            else
            {
                throw new IllegalArgumentException
                    ("This mapping is already a multiplex mapping.");
            }
        }
    }

    public void addMultiplexMapping(MultiplexMappingInfo mappingInfo) {
        if (mappingInfos.containsKey(mappingInfo.getBaseClass()) == false)
        {
            multiplexMappings.add(mappingInfo);
            mappingInfos.put(mappingInfo.getBaseClass(), mappingInfo);
        }
        else
        {
            Object o = mappingInfos.get(mappingInfo.getBaseClass());
            if (o instanceof ManualMappingInfo)
            {
                throw new IllegalArgumentException
                    ("This mapping is already a manual mapping.");
            }
            else
            {
                Log.info ("Duplicate Multiplex mapping: " + mappingInfo.getBaseClass(), new Exception());
            }
        }

    }

    public MultiplexMappingInfo lookupMultiplexMapping (Class baseClass)
    {
        Object o = mappingInfos.get(baseClass);
        if (o instanceof MultiplexMappingInfo)
        {
            return (MultiplexMappingInfo) o;
        }
        return null;
    }

}
