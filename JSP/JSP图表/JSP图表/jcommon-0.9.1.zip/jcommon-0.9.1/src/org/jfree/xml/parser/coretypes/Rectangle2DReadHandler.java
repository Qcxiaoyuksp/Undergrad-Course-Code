package org.jfree.xml.parser.coretypes;

import java.awt.geom.Rectangle2D;

import org.jfree.xml.parser.AbstractXmlReadHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class Rectangle2DReadHandler extends AbstractXmlReadHandler  {
    private Rectangle2D rectangle;

    public Rectangle2DReadHandler() {
    }

    protected void startParsing(Attributes attrs) throws SAXException {
        String type = attrs.getValue("type");
        this.rectangle = createRect(type);
        String x = attrs.getValue("x");
        String y = attrs.getValue("y");
        String w = attrs.getValue("width");
        String h = attrs.getValue("height");

        rectangle.setRect(Double.parseDouble(x), Double.parseDouble(y),
             Double.parseDouble(w), Double.parseDouble(h));
    }

    private Rectangle2D createRect (String type)
    {
        if ("float".equals(type))
        {
            return new Rectangle2D.Float();
        }
        return new Rectangle2D.Double();
    }

    public Object getObject() {
        return this.rectangle;
    }
}
