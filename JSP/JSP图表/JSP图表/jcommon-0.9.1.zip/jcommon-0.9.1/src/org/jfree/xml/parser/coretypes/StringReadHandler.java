/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ------------------------------
 * StringReadHandler.java
 * ------------------------------
 * (C)opyright 2003, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Simba Management Limited);
 *
 * $Id: StringReadHandler.java,v 1.2 2004/01/01 23:59:26 mungady Exp $
 *
 * Changes 
 * -------------------------
 * 03.12.2003 : Initial version
 *  
 */

package org.jfree.xml.parser.coretypes;

import org.jfree.xml.parser.AbstractXmlReadHandler;
import org.jfree.xml.parser.XmlReaderException;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;

/**
 * Required for list contents ...
 */
public class StringReadHandler extends AbstractXmlReadHandler {

    private StringBuffer buffer;
    private String result;

    public StringReadHandler() {
    }

    /**
     * Starts parsing.
     *
     * @param attrs  the attributes.
     *
     * @throws SAXException if there is a parsing error.
     */
    protected void startParsing(Attributes attrs) throws SAXException {
        buffer = new StringBuffer();
    }

    /**
     * This method is called to process the character data between element tags.
     *
     * @param ch  the character buffer.
     * @param start  the start index.
     * @param length  the length.
     *
     * @throws SAXException if there is a parsing error.
     */
    public void characters(char[] ch, int start, int length) throws SAXException {
        buffer.append(ch, start, length);
    }

    /**
     * Done parsing.
     *
     * @throws SAXException if there is a parsing error.
     */
    protected void doneParsing() throws SAXException, XmlReaderException {
        result = buffer.toString();
        buffer = null;
    }

    /**
     * Returns the object for this element.
     *
     * @return the object.
     */
    public Object getObject() {
        return result;
    }
}
