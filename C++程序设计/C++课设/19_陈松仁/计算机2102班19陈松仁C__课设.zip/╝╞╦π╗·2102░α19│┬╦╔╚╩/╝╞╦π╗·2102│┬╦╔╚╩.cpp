#include<iostream>
#include<string>
#include<fstream>
#include<vector>
using namespace std;
class student
{
private:
 string name, gender, major, address;
 int number, age;
public:
 student(string a, string b, string c, string d, int e, int f)
 {
  name = a; gender = b; major = c; address = d;
  number = e; age = f;
 }
 void show()
 {
  cout << "name:" << name << endl << "number:" << number << endl << "age:" << age << endl
   << "gender:" << gender << endl << "major:" << major << endl << "address:" << address << endl <<
   "************************************" << endl;
 }
 void modify()
 {
  cout << "�޸ĺ������:";
  getline(cin, name);
  cout << "�޸ĺ��ѧ��:";
  cin >> number; cin.get();
  cout << "�޸ĺ�����:";
  cin >> age; cin.get();
  cout << "�޸ĺ���Ա�:";
  getline(cin, gender);
  cout << "�޸ĺ��רҵ:";
  getline(cin, major);
  cout << "�޸ĺ�ĵ�ַ:";
  getline(cin, address);
 }
 string getname()
 {
  return name;
 }
 int getnumber()
 {
  return number;
 }
 int getage()
 {
  return age;
 }
 string getgender()
 {
  return gender;
 }
 string getmajor()
 {

  return major;
 }
 string getaddress()
 {
  return address;
 }
};
class sys
{
public:
 vector<student>vec;
 int count = 0;
public:
 void Menu()
 {
  cout << "**************************************" << endl;
  cout << "     1.show" << endl;
  cout << "     2.add" << endl;
  cout << "     3.find" << endl;
  cout << "     4.modify" << endl;
  cout << "     5.delete" << endl;
  cout << "     6.quit" << endl;
  cout << "**************************************" << endl;
 }
 void Show()
 {
  for (int i = 0; i < count; i++)
  {
   cout << i + 1 << "��" << endl;
   vec[i].show();
  }
  if (count == 0)
  {
   system("pause");
   system("cls");
  }

 }
 void Add()
 {
  string name, gender, major, address;
  int number, age;
  cout << "����:";
  getline(cin, name);
  cout << "ѧ��:";
  cin >> number; 
  cin.get();
  cout << "���:";
  cin >> age; 
  cin.get();
  cout << "�Ա�:";
  getline(cin, gender);
  cout << "רҵ:";
  getline(cin, major);
  cout << "��ַ:";
  getline(cin, address);
  vec.push_back(student(name, gender, major, address, number, age));
  count++;
  cout << "add done!" << endl;
  
 }
 void Modify()
 {
  Show();
  int a;
  cin >> a; cin.get();
  vec[a - 1].modify();
  cout << "modify done!" << endl;
  
 }
 void Find()
 {
  cout << "1.find by name" << endl << "2.find by number" << endl;
  int a;
  int count1 = 0;
  cin >> a; cin.get();
  if (a == 1) {
   cout << "input name :";
   string name;
   getline(cin, name);
   for (int i = 0; i < count; i++)
   {
    if (vec[i].getname() == name) { vec[i].show(); count1++;}
   }
   if (count1 == 0)
   {
    cout << "find failed" << endl;
   }
  
  }
  else {
   cout << "input number :";
   int number;
   int count1 = 0;
   cin >> number;
   cin.get();
   for (int i = 0; i < count; i++)
   {

    if (vec[i].getnumber() == number)
    {
     vec[i].show(); count1++;
    }
   }
   if (count1 == 0)
   {
    cout << "find failed" << endl;
   }
  }
  cout << "find done!" << endl;
 }
 void Delete()
 {
  Show();
  int a;
  cin >> a; cin.get();
  vec.erase(vec.begin() + a - 1);
  cout << "delete done!" << endl;
  count--;
 }
 void Save()
 {
  fstream of1,of2;
  of1.open("C:\\Users\\chens\\Desktop\\�����2102��19������\\�����2102��19������1.text", ios::out|ios::app);
  of2.open("C:\\Users\\chens\\Desktop\\�����2102��19������\\�����2102��19������2.text", ios::out|ios::app);
  for (int i = 0; i < count; i++)
  {
   of1 << vec[i].getname() << " " << vec[i].getnumber() << " " << vec[i].getage() << " " << vec[i].getgender() << " "
    << vec[i].getmajor() << " " << vec[i].getaddress() << endl;
  }
  of2 << count;
  of1.close();
  of2.close();
 }
 void Load()
 {
  fstream if1, if2;
  if1.open("C:\\Users\\chens\\Desktop\\�����2102��19������\\�����2102��19������2.text", ios::in|ios::app);
  if (if1.is_open())
  {
   if1 >> count;
   fstream if2;
   if2.open("C:\\Users\\chens\\Desktop\\�����2102��19������\\�����2102��19������1.text", ios::in|ios::app);
    for (int i = 0; i < count; i++)
    {
     string name, gender, major, address;
     int number, age;
     if2 >> name >> number >> age >> gender >> major >> address;
     vec.push_back(student(name, gender, major, address, number, age));
    }
    if2.close();
   
  }
  else {
  }
  if1.close();
 }
};

int main()
{
 sys  s;
 s.Load();
 for (;;)
 {
  s.Menu();
  int a;
  cin >> a; cin.get();
  if (a == 1)
  {
   s.Show();
   system("pause");
   system("cls");
  }
  else if (a == 2)
  {
   s.Add();
   system("pause");
   system("cls");
  }
  else if (a == 3)
  {
   s.Find();
   system("pause");
   system("cls");
  }
  else if (a == 4)
  {
   s.Modify(); 
   system("pause");
   system("cls");
  }
  else if (a == 5)
  {
   s.Delete(); 
   system("pause");
   system("cls");

  }
  else if (a == 6)
  {
   s.Save();
   return 0;
  }
  else {
   cout << "input wrong!" << endl;
   system("pause");
   system("cls");
  }
 }
}
