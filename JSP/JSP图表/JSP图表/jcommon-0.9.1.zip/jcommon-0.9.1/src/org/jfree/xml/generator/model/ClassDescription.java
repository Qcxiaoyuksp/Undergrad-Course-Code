/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ---------------------
 * ClassDescription.java
 * ---------------------
 * (C)opyright 2003, 2004, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: ClassDescription.java,v 1.6 2004/01/01 23:59:31 mungady Exp $
 *
 * Changes
 * -------
 * 21-Jun-2003 : Initial version (TM);
 * 26-Nov-2003 : Updated header and Javadocs (DG);
 * 
 */

package org.jfree.xml.generator.model;

import org.jfree.xml.generator.model.PropertyInfo;

/**
 * A description of a Java class.
 */
public class ClassDescription {

    /** Storage for info about properties. */
    private PropertyInfo[] properties;
    
    /** Constructor descriptions. */
    private TypeInfo[] constructorDescription;
    
    /** The class. */
    private Class objectClass;
    
    /** A description. */
    private String description;
    
    /** The register key. */
    private String registerKey;
    
    /** The super class. */
    private Class superClass;
    
    /** ??. */
    private boolean preserve;
    private Comments comments;
    private String source;

    /**
     * Creates a new class description.
     * 
     * @param objectClass  the class.
     */
    public ClassDescription(Class objectClass) {
        if (objectClass == null) {
            throw new NullPointerException();
        }
        this.objectClass = objectClass;
    }

    /**
     * Returns the info about properties.
     * 
     * @return the info about properties.
     */
    public PropertyInfo[] getProperties() {
        return this.properties;
    }

    /**
     * Sets the info about the class properties.
     * 
     * @param properties  the properties.
     */
    public void setProperties(PropertyInfo[] properties) {
        this.properties = properties;
    }

    /**
     * Returns the object's class.
     * 
     * @return the object's class.
     */
    public Class getObjectClass() {
        return this.objectClass;
    }

    /**
     * Returns the description.
     * 
     * @return the description.
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * Sets the description for the object.
     * 
     * @param description  the description.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the class name.
     * 
     * @return the class name.
     */
    public String getName() {
        if (getObjectClass() == null) {
            return null;
        }
        return getObjectClass().getName();
    }

    /**
     * Returns the super class.
     * 
     * @return the super class.
     */
    public Class getSuperClass() {
        return this.superClass;
    }

    /**
     * Sets the super class.
     * 
     * @param superClass  the super class.
     */
    public void setSuperClass(Class superClass) {
        this.superClass = superClass;
    }

    /**
     * Returns the preserve flag.
     * 
     * @return a boolean.
     */
    public boolean isPreserve() {
        return preserve;
    }

    /**
     * Sets the preserve flag.
     * 
     * @param preserve  the new value of the flag.
     */
    public void setPreserve(boolean preserve) {
        this.preserve = preserve;
    }

    /**
     * Returns the register key.
     * 
     * @return the register key.
     */
    public String getRegisterKey() {
        return registerKey;
    }

    /**
     * Sets the register key.
     * 
     * @param registerKey the register key.
     */
    public void setRegisterKey(String registerKey) {
        this.registerKey = registerKey;
    }

    /**
     * Returns the constructor descriptions.
     * 
     * @return the constructor descriptions.
     */
    public TypeInfo[] getConstructorDescription() {
        return constructorDescription;
    }

    /**
     * Sets the constructor description.
     * 
     * @param constructorDescription  the constructor description.
     */
    public void setConstructorDescription(TypeInfo[] constructorDescription) {
        this.constructorDescription = constructorDescription;
    }

    /**
     * Returns a property.
     * 
     * @param name  the property name.
     * 
     * @return a property.
     */
    public PropertyInfo getProperty (String name) {
        if (this.properties == null) {
            return null;
        }
        for (int i = 0; i < properties.length; i++) {
            if (properties[i].getName().equals(name)) {
                return properties[i];
            }
        }
        return null;
    }

    public boolean isUndefined() {
        if (properties != null) {
            if (properties.length > 0) {
                return false;
            }
        }
        if (isPreserve()) {
            return false;
        }
        if (getRegisterKey() != null) {
            return false;
        }
        if (getConstructorDescription() != null) {
            if (getConstructorDescription().length > 0) {
                return false;
            }
        }
        return true;
    }

    public Comments getComments() {
        return comments;
    }

    public void setComments(Comments comments) {
        this.comments = comments;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}

