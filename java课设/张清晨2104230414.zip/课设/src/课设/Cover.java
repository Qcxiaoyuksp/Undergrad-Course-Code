package ����;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class Cover extends JFrame {	//�̳�JFrame��
	private JPanel contentPane;
	private JTextField txtBeta;
	/**
	 *����Ӧ�ó���
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cover frame = new Cover();
					frame.setVisible(true);//��ʾ����
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 *�������
	 */
	public Cover() {
		setTitle("Digital products");//����
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(750,350,450,300);//�����С
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);//��屳����ɫ
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		/**
		 *���ý������
		 */
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBackground(SystemColor.menu);
		textArea.setFont(new Font("����",Font.PLAIN,21));
		textArea.setText("Digital products information system");
		textArea.setBounds(22,45,385,30);
		contentPane.add(textArea);
		/**
		 *����Exit��ť
		 */
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				java.lang.System.exit(0);
			}
		});
		btnExit.setBounds(260,150,110,30);
		contentPane.add(btnExit);
		/**
		 *����Enter��ť
		 */
		JButton btnEnter = new JButton("Enter");
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0){
				Table frame = new Table();
				frame.setVisible(true);
			}
		});
		btnEnter.setBounds(60,150,110,30);
		contentPane.add(btnEnter);
	}
}