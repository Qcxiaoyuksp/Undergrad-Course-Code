/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ------------------------
 * JavaSourceCollector.java
 * ------------------------
 * (C)opyright 2003, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: JavaSourceCollector.java,v 1.6 2004/01/01 23:59:30 mungady Exp $
 *
 * Changes
 * -------------------------
 * 21.06.2003 : Initial version
 *
 */

package org.jfree.xml.generator;

import java.io.File;
import java.io.FileFilter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

import org.jfree.ui.ExtensionFileFilter;
import org.jfree.util.Log;

/**
 * The class collects all class-files and loads the class objects named
 * by these files.
 */
public class JavaSourceCollector implements SourceCollector {

    private static class CollectorFileFilter
        extends ExtensionFileFilter implements FileFilter {
        public CollectorFileFilter(String description, String extension) {
            super(description, extension);
        }
    }

    private CollectorFileFilter eff;
    private ArrayList fileList;
    private ArrayList ignoredPackages;
    private ArrayList ignoredBaseClasses;
    private File startDirectory;
    private String initialPackageName;

    public JavaSourceCollector(File startDirectory, String packageName) {
        eff = new CollectorFileFilter("<ignore>", ".java");
        fileList = new ArrayList();
        this.startDirectory = startDirectory;
        this.initialPackageName = packageName;
        this.ignoredPackages = new ArrayList();
        this.ignoredBaseClasses = new ArrayList();
    }

    public JavaSourceCollector(File startDirectory) {
        this(startDirectory, "");
    }

    public void addIgnoredPackage(String pkg) {
        Log.debug (new Log.SimpleMessage("Added IgnPackage: " , pkg));
        ignoredPackages.add(pkg);
    }

    public void addIgnoredBaseClass(String baseClass) {
        Class loadedClass = loadClass(baseClass);
        if (loadedClass != null) {
            Log.debug (new Log.SimpleMessage("Added IgnClass: " , baseClass));
            ignoredBaseClasses.add(loadedClass);
        }
    }

    public void addIgnoredBaseClass(Class baseClass) {
        ignoredBaseClasses.add(baseClass);
    }

    protected boolean isIgnoredPackage(String classname) {
        for (int i = 0; i < ignoredPackages.size(); i++) {
            String ignoredPackage = (String) ignoredPackages.get(i);
            if (classname.startsWith(ignoredPackage)) {
                return true;
            }
        }
        return false;
    }

    protected boolean isIgnoredBaseClass(Class c) {
        for (int i = 0; i < ignoredBaseClasses.size(); i++) {
            Class ignoredClass = (Class) ignoredBaseClasses.get(i);
            if (ignoredClass.isAssignableFrom(c)) {
                return true;
            }
        }
        return false;
    }

    public void collectFiles() {
        collectFiles(startDirectory, initialPackageName);
    }

    protected void collectFiles(File directory, String packageName) {
        File[] files = directory.listFiles(eff);
        for (int i = 0; i < files.length; i++) {
            if (files[i].isDirectory() == true) {
                collectFiles(files[i], buildJavaName(packageName, files[i].getName()));
            }
            else {
                String fname = files[i].getName();
                String className = fname.substring(0, fname.length() - 5);
                String fullName = buildJavaName(packageName, className);
                if (isIgnoredPackage(fullName)) {
                    Log.debug (new Log.SimpleMessage("Do not process: Ignored: ", className));
                    continue;
                }
                Class jclass = loadClass(fullName);
                if (jclass == null || isIgnoredBaseClass(jclass)) {
                    continue;
                }
                if (jclass.isInterface() || Modifier.isAbstract(jclass.getModifiers())) {
                    Log.debug (new Log.SimpleMessage("Do not process: Abstract: ", className));
                    continue;
                }
                if (Modifier.isPublic(jclass.getModifiers()) == false)
                {
                    Log.debug (new Log.SimpleMessage("Do not process: Not public: ", className));
                    continue;
                }
                if (jclass != null) {
                    fileList.add(jclass);
                }
            }
        }
    }

    protected Class loadClass(String name) {
        try {
            return Class.forName(name);
        }
        catch (Exception e) {
            Log.warn (new Log.SimpleMessage("Do not process: Failed to load class:", name));
            return null;
        }
    }

    protected String buildJavaName(String packageName, String newPackage) {
        if (packageName.length() == 0) {
            return newPackage;
        }
        else {
            return packageName + "." + newPackage;
        }
    }

    public Class[] getClasses() {
        return (Class[]) fileList.toArray(new Class[0]);
    }
}
