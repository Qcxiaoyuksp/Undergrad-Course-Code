/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ------------------------------
 * SimpleObjectFactory.java
 * ------------------------------
 * (C)opyright 2003, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Simba Management Limited);
 *
 * $Id: SimpleObjectFactory.java,v 1.2 2004/01/01 23:59:29 mungady Exp $
 *
 * Changes 
 * -------------------------
 * 02.12.2003 : Initial version
 *  
 */

package org.jfree.xml.util;

import java.util.HashMap;

public class SimpleObjectFactory implements ObjectFactory {

    private HashMap objectMappings;
    private HashMap manualMappings;
    private HashMap multiplexMappings;

    public SimpleObjectFactory() {
        objectMappings = new HashMap();
        manualMappings = new HashMap();
        multiplexMappings = new HashMap();
    }

    public void addManualMapping (ManualMappingDefinition mapping)
    {
        manualMappings.put(mapping.getBaseClass(), mapping);
    }

    public void addGenericHandler (GenericObjectFactory handler)
    {
        objectMappings.put(handler.getBaseClass(), handler);
    }

    public void addMultiplexMapping (MultiplexMappingDefinition mplex)
    {
        multiplexMappings.put (mplex.getBaseClass(), mplex);
    }

    public void clear ()
    {
        objectMappings.clear();
        manualMappings.clear();
        multiplexMappings.clear();
    }

    /**
     * Returns a factory instance for the given class. The factory is independent
     * from all previously generated instances.
     *
     * @param c the class
     * @return the object factory.
     */
    public GenericObjectFactory getFactoryForClass(Class c) {
        GenericObjectFactory factory = (GenericObjectFactory) objectMappings.get(c);
        if (factory == null) {
            return null;
        }
        return factory.getInstance();
    }

    /**
     * Returns the manual mapping definition for the given class, or null, if
     * not manual definition exists.
     *
     * @param c the class for which to check the existence of the definition
     * @return the manual mapping definition or null.
     */
    public ManualMappingDefinition getManualMappingDefinition(Class c) {
        return (ManualMappingDefinition) manualMappings.get(c);
    }

    /**
     * Returns the multiplex definition for the given class, or null, if no
     * such definition exists.
     *
     * @param c the class for which to check the existence of the multiplexer
     * @return the multiplexer for the class, or null if no multiplexer exists.
     */
    public MultiplexMappingDefinition getMultiplexDefinition(Class c) {
        MultiplexMappingDefinition definition = (MultiplexMappingDefinition)
            multiplexMappings.get(c);
        return definition;
    }

    /**
     * Checks, whether a generic handler exists for the given class. This does
     * not check, whether an mapping exists.
     *
     * @param c the class for which to check
     * @return true, if an generic handler is defined, false otherwise.
     */
    public boolean isGenericHandler(Class c) {
        return objectMappings.containsKey(c);
    }
}
