/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * --------------
 * TextBlock.java
 * --------------
 * (C) Copyright 2003, 2004, by Object Refinery Limited and Contributors.
 *
 * Original Author:  David Gilbert (for Object Refinery Limited);
 * Contributor(s):   -;
 *
 * $Id: TextBlock.java,v 1.4 2004/01/08 16:13:09 mungady Exp $
 *
 * Changes
 * -------
 * 07-Nov-2003 : Version 1 (DG);
 * 22-Dec-2003 : Added workaround for Java bug 4245442 (DG);
 * 09-Jan-2004 : Added an extra draw(...) method for no rotation case (DG);
 *
 */
 
package org.jfree.text;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.Iterator;
import java.util.List;

import org.jfree.ui.TextAnchor;

/**
 * A list of {@link TextLine} objects that form a block of text.
 * 
 * @author David Gilbert
 */
public class TextBlock {

    /** Storage for the lines of text. */
    private List lines;
    
    /**
     * Creates a new empty text block.
     */
    public TextBlock() {
        this.lines = new java.util.ArrayList();
    }
    
    /**
     * Adds a line of text that will be displayed using the specified font.
     * 
     * @param text  the text.
     * @param font  the font.
     */
    public void addLine(String text, Font font) {
        addLine(new TextLine(text, font));
    }
    
    /**
     * Adds a {@link TextLine} to the block.
     * 
     * @param line  the line.
     */
    public void addLine(TextLine line) {
        this.lines.add(line);    
    }
    
    /**
     * Returns the last line in the block.
     * 
     * @return the last line in the block.
     */
    public TextLine getLastLine() {
        TextLine last = null;
        int index = this.lines.size() - 1;
        if (index >= 0) {
            last = (TextLine) this.lines.get(index);
        }
        return last;
    }
    
    /**
     * Returns the width and height of the text block.
     * 
     * @param g2  the graphics device.
     * 
     * @return the width and height.
     */
    public Dimension calculateDimensions(Graphics2D g2) {
        Dimension result = new Dimension();
        double width = 0.0;
        double height = 0.0;
        Iterator iterator = this.lines.iterator();
        while (iterator.hasNext()) {
            TextLine line = (TextLine) iterator.next();
            Dimension dimension = line.calculateDimensions(g2);
            width = Math.max(width, dimension.getWidth());
            height = height + dimension.getHeight();
        }
        result.setSize((int) Math.ceil(width), (int) Math.ceil(height));
        return result;
    }
    
    /**
     * Draws the text block at a specific location.
     * 
     * @param g2  the graphics device.
     * @param x  the x-coordinate for the anchor point.
     * @param y  the y-coordinate for the anchor point.
     * @param anchor  the anchor point.
     */
    public void draw(Graphics2D g2, float x, float y, TextBlockAnchor anchor) {
        draw(g2, x, y, anchor, 0.0f, 0.0f, 0.0);
    }
    
    /**
     * Draws the text block, aligning it with the specified anchor point and rotating it about
     * the specified rotation point.
     * 
     * @param g2  the graphics device.
     * @param anchorX  the x-coordinate for the anchor point.
     * @param anchorY  the y-coordinate for the anchor point.
     * @param anchor  the point on the text block that is aligned to the anchor point.
     * @param rotateX  the x-coordinate for the rotation point.
     * @param rotateY  the x-coordinate for the rotation point.
     * @param angle  the rotation (in radians).
     */
    public void draw(Graphics2D g2, 
                     float anchorX, float anchorY, TextBlockAnchor anchor,
                     float rotateX, float rotateY, double angle) {
    
        Dimension d = calculateDimensions(g2);
        float[] offsets = calculateOffsets(anchor, d.getWidth(), d.getHeight());
        Iterator iterator = this.lines.iterator();
        float yCursor = 0.0f;
        while (iterator.hasNext()) {
            TextLine line = (TextLine) iterator.next();
            line.draw(g2, anchorX + offsets[0], anchorY + offsets[1] + yCursor, TextAnchor.TOP_LEFT, rotateX, rotateY, angle);
            Dimension dimension = line.calculateDimensions(g2);
            yCursor = yCursor + (float) dimension.getHeight();
        }
        
    }
 
    /**
     * Calculates the x and y offsets required to align the text block with the specified
     * anchor point.  This assumes that the top left of the text block is at (0.0, 0.0).
     * 
     * @param anchor  the anchor position.
     * @param width  the width of the text block.
     * @param height  the height of the text block.
     * 
     * @return  the offsets (float[0] = x offset, float[1] = y offset).
     */
    private float[] calculateOffsets(TextBlockAnchor anchor, double width, double height) {
        float[] result = new float[2];
        float xAdj = 0.0f;
        float yAdj = 0.0f;

        if (anchor == TextBlockAnchor.TOP_CENTER
                || anchor == TextBlockAnchor.CENTER
                || anchor == TextBlockAnchor.BOTTOM_CENTER) {
                    
            xAdj = (float) -width / 2.0f;
            
        }
        else if (anchor == TextBlockAnchor.TOP_RIGHT
                || anchor == TextBlockAnchor.CENTER_RIGHT
                || anchor == TextBlockAnchor.BOTTOM_RIGHT) {
                    
            xAdj = (float) -width;
            
        }

        if (anchor == TextBlockAnchor.TOP_LEFT
                || anchor == TextBlockAnchor.TOP_CENTER
                || anchor == TextBlockAnchor.TOP_RIGHT) {
                    
            yAdj = 0.0f;
            
        }
        else if (anchor == TextBlockAnchor.CENTER_LEFT
                || anchor == TextBlockAnchor.CENTER
                || anchor == TextBlockAnchor.CENTER_RIGHT) {
                    
            yAdj = (float) -height / 2.0f;
            
        }
        else if (anchor == TextBlockAnchor.BOTTOM_LEFT
                || anchor == TextBlockAnchor.BOTTOM_CENTER
                || anchor == TextBlockAnchor.BOTTOM_RIGHT) {
                    
            yAdj = (float) -height;
            
        }
        result[0] = xAdj;
        result[1] = yAdj;
        return result;
    }   
    
}
