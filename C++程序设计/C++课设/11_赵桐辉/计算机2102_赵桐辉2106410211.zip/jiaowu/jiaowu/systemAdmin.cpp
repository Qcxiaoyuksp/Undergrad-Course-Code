#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include "student.h"
#include "systemAdmin.h"
using namespace std;

systemAdmin::systemAdmin()
{
	userName = "";
}

void systemAdmin::setSystemAdmin(string userName)
{
	this->userName = userName;
}

void systemAdmin::inputStudentBasicInfo(student* s, int& studentNum)
{
	string new_studentNumber;
	string new_name;
	string new_sex;
	string new_majorAndClass;
	string new_birth;
	string new_politicStatus;
	string new_address;

	cout << "����ѧ��������Ϣ��" << endl;
	cout << "    ����ѧ��ѧ�ţ�";
	cin >> new_studentNumber;

	bool m = true;
	for (int i = 0; i < studentNum; i++)
		if (new_studentNumber == s[i].getStudentNumber())
			m = false;

	if (m)
	{
		cout << "\tѧ��������";
		cin >> new_name;
		cout << "\tѧ���Ա�";
		cin >> new_sex;
		cout << "\tרҵ�༶��";
		cin >> new_majorAndClass;
		cout << "\t�������£�";
		cin >> new_birth;
		cout << "\t������ò��";
		cin >> new_politicStatus;
		cout << "\t��ͥסַ��";
		cin >> new_address;

		s[studentNum].studentNumber = new_studentNumber;
		s[studentNum].name = new_name;
		s[studentNum].sex = new_sex;
		s[studentNum].majorAndClass = new_majorAndClass;
		s[studentNum].birth = new_birth;
		s[studentNum].politicStatus = new_politicStatus;
		s[studentNum].address = new_address;

		studentNum++;
	}
	else
		cout << "���и�ѧ����Ϣ��������¼�룡����" << endl;

}

void systemAdmin::deleteStudentBasicInfo(student* s, string studentNumber, int& studentNum)
{
	for (int i = 0; i < studentNum - 1; i++)
		if (studentNumber == s[i].getStudentNumber())
		{
			for (i; i < studentNum - 1; i++)
				s[i] = s[i + 1];

			studentNum--;
		}
}

void systemAdmin::ModificareStudentBasicInfo(student* s, string studentNumber, int& studentNum)
{
	string re_name;
	string re_sex;
	string re_majorAndClass;
	string re_birth;
	string re_politicStatus;
	string re_address;

	cout << "\tѧ��������";
	cin >> re_name;
	cout << "\tѧ���Ա�";
	cin >> re_sex;
	cout << "\tרҵ�༶��";
	cin >> re_majorAndClass;
	cout << "\t�������£�";
	cin >> re_birth;
	cout << "\t������ò��";
	cin >> re_politicStatus;
	cout << "\t��ͥסַ��";
	cin >> re_address;

	s[studentNum].name = re_name;
	s[studentNum].sex = re_sex;
	s[studentNum].majorAndClass = re_majorAndClass;
	s[studentNum].birth = re_birth;
	s[studentNum].politicStatus = re_politicStatus;
	s[studentNum].address = re_address;

}

void systemAdmin::writeToTxtFileA() const
{
	ofstream txtOut("systemAdminBasicInfo.txt", ios::app);

	txtOut << userName << "  " << password << endl;

	txtOut.close();
}
void systemAdmin::readFromTxtFileA(int num)
{
	fstream txtIn("systemAdminBasicInfo.txt", ios::in);
	string temp;
	int line = 1;
	if (num == 1)
		txtIn >> userName >> password;
	else
	{
		while (getline(txtIn, temp, '\n'))
		{
			line++;
			if (line == num)
				txtIn >> userName >> password;
		}

	}
	txtIn.close();
}



