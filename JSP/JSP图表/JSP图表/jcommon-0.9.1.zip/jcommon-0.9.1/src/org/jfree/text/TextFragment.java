/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * -----------------
 * TextFragment.java
 * -----------------
 * (C) Copyright 2003, 2004, by Object Refinery Limited and Contributors.
 *
 * Original Author:  David Gilbert (for Object Refinery Limited);
 * Contributor(s):   -;
 *
 * $Id: TextFragment.java,v 1.7 2004/01/01 23:59:30 mungady Exp $
 *
 * Changes
 * -------
 * 07-Nov-2003 : Version 1 (DG);
 * 25-Nov-2003 : Fixed bug in the dimension calculation (DG);
 * 22-Dec-2003 : Added workaround for Java bug 4245442 (DG);
 *
 */
 
package org.jfree.text;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.font.LineMetrics;
import java.awt.geom.Rectangle2D;

import org.jfree.ui.RefineryUtilities;
import org.jfree.ui.TextAnchor;

/**
 * A text item, with an associated font, that fits on a single line (see {@link TextLine}).
 * 
 * @author David Gilbert
 */
public class TextFragment {

    /** The default font. */
    public static final Font DEFAULT_FONT = new Font("Serif", Font.PLAIN, 12);
    
    /** The text. */
    private String text;
    
    /** The font. */
    private Font font;

    /**
     * Creates a new text fragment.
     * 
     * @param text  the text.
     */
    public TextFragment(String text) {
        this(text, DEFAULT_FONT);
    }
    
    /**
     * Creates a new text fragment.
     * 
     * @param text  the text.
     * @param font  the font.
     */
    public TextFragment(String text, Font font) {
        this.text = text;
        this.font = font;
    }

    /**
     * Returns the text.
     * 
     * @return the text.
     */
    public String getText() {
        return this.text;
    }
    
    /**
     * Returns the font.
     * 
     * @return the font.
     */
    public Font getFont() {
        return this.font;
    }
    
    /**
     * Calculates the dimensions of the text fragment.
     * 
     * @param g2  the graphics device.
     * 
     * @return the width and height.
     */
    public Dimension calculateDimensions(Graphics2D g2) {
        Dimension result = new Dimension();
        g2.setFont(this.font);
        FontMetrics fm = g2.getFontMetrics();
        Rectangle2D bounds = fm.getStringBounds(this.text, g2);
        result.setSize((int) Math.ceil(bounds.getWidth()), (int) Math.ceil(bounds.getHeight()));
        return result;
    }
    
    /**
     * Draws the text fragment.
     * 
     * @param g2  the graphics device.
     * @param anchorX  the x-coordinate of the anchor point.
     * @param anchorY  the y-coordinate of the anchor point.
     * @param anchor  the location of the text that is aligned to the anchor point.
     * @param rotateX  the x-coordinate of the rotation point.
     * @param rotateY  the y-coordinate of the rotation point.
     * @param angle  the angle.
     */
    public void draw(Graphics2D g2, 
                     float anchorX, float anchorY, TextAnchor anchor,
                     float rotateX, float rotateY, double angle) {
    
        g2.setFont(this.font);
        RefineryUtilities.drawRotatedString(this.text, g2, anchorX, anchorY, anchor, rotateX, rotateY, angle);
    
    }
    
    /**
     * Calculates the vertical offset between the baseline and the specified text anchor.
     * 
     * @param g2  the graphics device.
     * @param anchor  the anchor.
     * 
     * @return the offset.
     */
    public float calculateBaselineOffset(Graphics2D g2, TextAnchor anchor) {
        float result = 0.0f;
        FontMetrics fm = g2.getFontMetrics(this.font);
        LineMetrics lm = fm.getLineMetrics("ABCxyz", g2);
        if (anchor == TextAnchor.TOP_LEFT || anchor == TextAnchor.TOP_CENTER
                                          || anchor == TextAnchor.TOP_RIGHT) {
            result = lm.getAscent();
        }
        else if (anchor == TextAnchor.BOTTOM_LEFT || anchor == TextAnchor.BOTTOM_CENTER
                                                  || anchor == TextAnchor.BOTTOM_RIGHT) {
            result = -lm.getDescent() - lm.getLeading();
        }
        return result;                                             
    }
        
}
