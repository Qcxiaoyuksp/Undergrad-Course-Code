#include<iostream>
#include<string>
#include <fstream>
#include<windows.h>
#include<conio.h>
#include <iomanip>
using namespace std;
class Student{
	private:
		int student_ID;
	    string name;
		int chinese_score;
		int math_score;
		int english_score;
		double aver;
		friend class Students;
	public:
		void setId(int i);
		int getId();
		void setName(string s1);
		string getName();
		void setChinese(int x1);
		int getChinese();
		void setMath(int x2);
		int getMath();
		void setEnglish(int x3);
		int getEnglish();
		void setaver(double f1);
		double getaver();
		
};
class Students{
	private:
		Student a[100];
		Student b[100];
	public:
		void input();
		void print();
		void sort();
		void modify();

};
int main();
void Student::setId(int i)
{
	student_ID=i;
}
int Student::getId()
{
	return 	student_ID;
}
void Student::setName(string s1)
{
	this->name=s1;
}
string Student::getName()
{
	string p=this->name;
	return p;
}
void Student::setChinese(int x1)
{
	chinese_score=x1;
}
int Student::getChinese()
{
	return chinese_score;
}
void Student::setMath(int x2)
{
	math_score=x2;
}
int Student::getMath()
{
	return math_score;
}
void Student::setEnglish(int x3)
{
	english_score=x3;
}
int Student::getEnglish()
{
	return english_score;
}
void Student::setaver(double f1)
{
	aver=f1;
}
double Student::getaver()
{
	return aver;
}
void show()
{
cout<<"\n ++++++++++++++++++++++++++++++++++++++++++MENU+++++++++++++++++++++++++++=++++++++++\n";
cout<<"\n                      ============================================\n";
cout<<"\n +++++++++++++++++++||       A: ¼��ѧ����Ϣ   B: ��ѯѧ���ɼ�    ||+++++++++++++++++\n";
cout<<"\n +++++++++++++++++++||       C: ѧ���ɼ�����   D: ��Ϣɾ�����޸�  ||+++++++++++++++++\n";
cout<<"\n +++++++++++++++++++||             	E. �˳�ϵͳ                ||+++++++++++++++++\n";
cout<<"\n                      ============================================\n";
cout<<"\n ++++++++++++++++++++++++++++++++++++++++++++++++++++++=++++++++++\n";

cout<<endl<<"��ѡ��Ŀ¼:";
}
void Students::input()
{
	int n,x,i;
	string s1="sda";
	double f1;
	
	ifstream in;
	in.open("student grade.txt", ios::in|ios::binary);
	if (!in)
	{
		cout << "�ļ���ʧ�ܣ�" << endl;
	}
	for(i=0;i<100; i++)
		in.read((char*)&a[i], sizeof(a[i]));
	
	cout<<"������ѧ��:";
	cin>>n;
	a[n].setId(n);
	cout<<"����:";
	cin>>s1;
	a[n].setName(s1);
	cout<<"����:";
	cin>>x;
	a[n].setChinese(x);
	cout<<"��ѧ:";
	cin>>x;
	a[n].setMath(x);
	cout<<"Ӣ��:";
	cin>>a[n].english_score;
	a[n].setEnglish(x);

	f1=(a[n].getChinese()+a[n].getMath()+a[n].getEnglish())*1.0/3.0;
	a[n].setaver(f1);
	
	in.close();
	
	ofstream out;
	out.open("student grade.txt", ios::out|ios::binary);
	if (!out)
	{
		cout << "�ļ���ʧ�ܣ�" << endl;
	}
	for(int i=0; i<100; i++)
		out.write((char*)&a[i], sizeof(a[i]));
	out.close();
	
	Sleep(3000);
	system("cls");
	main();

}
void Students::print()
{
	int i;
	ifstream in;
	in.open("student grade.txt", ios::in|ios::binary);
	if (!in)
	{
		cout << "�ļ���ʧ�ܣ�" << endl;
	}
	for(i=0;i<100; i++)
	in.read((char*)&a[i], sizeof(a[i]));
	cout<<"����Ҫ��ѯ��ѧ��:";
	cin>>i;
	if(a[i].getId()!=0)
	{
		cout<<"ѧ��:"<<a[i].getId()<<endl;
		cout<<"����:"<<a[i].getName()<<endl;
		cout<<"����:"<<a[i].getChinese()<<endl;
		cout<<"��ѧ:"<<a[i].getMath()<<endl;
		cout<<"Ӣ��:"<<a[i].getEnglish()<<endl;
		cout<<"ƽ���ɼ�:"<<a[i].getaver()<<endl<<endl;
	}
	if(a[i].getId()==0)
	{
		cout<<"��ѧ�Ų����ڣ�"<<endl; 
	}
	in.close();
	
	Sleep(3000);
	system("cls");
	main();

}
void Students::sort()
{
	int i,k,m,index,id;
	Student temp;
	double aver1,aver2;
	m=0;

	ifstream in;
	in.open("student grade.txt", ios::in|ios::binary);
	if (!in)
	{
		cout << "�ļ���ʧ�ܣ�" << endl;
	}
	for(i=0;i<100; i++)
		in.read((char*)&a[i], sizeof(a[i]));
		
	for(i=0; i<100; i++)
	{
		id=a[i].getId();
		if(id!=0)
		{
			b[m]=a[i];
			m++;
		}
	}

	for(k=0; k<m-1; k++)
	{
		index=k;
		for(i=k+1; i<m; i++)
		{
			aver1=b[i].getaver();
			aver2=b[index].getaver();
			if(aver1<aver2)
			{
				index=i;
			}
		}
		temp=b[index];
		b[index]=b[k];
		b[k]=temp;
	}
	for(i=0;i<m; i++)
	{
		cout<<"ѧ��:"<<b[i].getId()<<endl;
		cout<<"����:"<<b[i].getName()<<endl;
		cout<<"����:"<<b[i].getChinese()<<endl;
		cout<<"��ѧ:"<<b[i].getMath()<<endl;
		cout<<"Ӣ��:"<<b[i].getEnglish()<<endl;
		cout<<"ƽ���ɼ�:"<<b[i].getaver()<<endl;
	}
	in.close();
	
	Sleep(3000);
	system("cls");
	main();
}
void Students::modify()
{
	int password,n,x,score,choice;
	
	double f1;
	ifstream in;
	in.open("student grade.txt", ios::in|ios::binary);
	if (!in)
	{
		cout << "�ļ���ʧ�ܣ�" << endl;
	}
	for(int i=0;i<100; i++)
	in.read((char*)&a[i], sizeof(a[i]));
	
	cout<<"����Ҫ�޸ĵ�ѧ����ѧ��:";
	cin>>x;
	cout<<endl<<"1.�޸�    2.ɾ��"<<endl; 
	cin>>choice;
	if(choice==1)
	{	
		cout<<"1.����-------2.��ѧ-------3.Ӣ��-------"<<endl;
		cout<<"������Ҫ�޸ĵĿ�Ŀ:";
		cin>>n;
		
		if(n>=1&&n<=3)
		{
			cout<<"�����޸ĺ�ĳɼ�:"<<endl;
			cin>>score;
		}
		else	
		{
			printf("invalid command!");
			
		
		}
		switch(n)
		{
			case 1:
				a[x].setChinese(score);
				f1=(a[n].getChinese()+a[n].getMath()+a[n].getEnglish())*1.0/3;
				a[x].setaver(f1);
				break;
			case 2: 
				a[x].setMath(score);	
				f1=(a[n].getChinese()+a[n].getMath()+a[n].getEnglish())*1.0/3;
				a[x].setaver(f1);
				break;
			case 3:
				a[x].setEnglish(score);
				f1=(a[n].getChinese()+a[n].getMath()+a[n].getEnglish())*1.0/3;
				a[x].setaver(f1);
				break;
		}
	}
	if(choice==2)
	{
		a[x].setId(0);
		a[x].setName("null");
		a[x].setChinese(0);
		a[x].setMath(0);
		a[x].setEnglish(0);
		a[x].setaver(0);
	}
	in.close();
	
	ofstream out;
	out.open("student grade.txt", ios::out|ios::binary);
	if (!out)
	{
		cout << "�ļ���ʧ�ܣ�" << endl;
	}
	for(int i=0; i<100; i++)
	out.write((char*)&a[i], sizeof(a[i]));
	out.close();
	
	Sleep(3000);
	system("cls");
	main();
}
int main()
{
	char ch;
	Students stu;
	show();
	cin>>ch;
	switch(ch)
	{
		case 'A':
			stu.input();	break;
		case 'B':
			stu.print();	break;
		case 'C':
			stu.sort();		break;
		case 'D':
			stu.modify();  break;
		case 'E':
			exit;		break;
		
		default:
			cout<<"error!";	break;
	}
	
}

