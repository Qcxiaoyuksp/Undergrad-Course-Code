/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ----------------
 * ModelWriter.java
 * ----------------
 * (C)opyright 2003, 2004, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: ModelWriter.java,v 1.8 2004/01/01 23:59:30 mungady Exp $
 *
 * Changes
 * -------------------------
 * 21.06.2003 : Initial version
 *
 */

package org.jfree.xml.generator;

import java.io.IOException;
import java.io.Writer;

import org.jfree.xml.generator.model.ClassDescription;
import org.jfree.xml.generator.model.DescriptionModel;
import org.jfree.xml.generator.model.IgnoredPropertyInfo;
import org.jfree.xml.generator.model.ManualMappingInfo;
import org.jfree.xml.generator.model.MultiplexMappingInfo;
import org.jfree.xml.generator.model.PropertyInfo;
import org.jfree.xml.generator.model.PropertyType;
import org.jfree.xml.generator.model.TypeInfo;
import org.jfree.xml.generator.model.Comments;
import org.jfree.xml.util.ClassModelTags;
import org.jfree.xml.writer.AttributeList;
import org.jfree.xml.writer.SafeTagList;
import org.jfree.xml.writer.XMLWriterSupport;

public class ModelWriter {

    private static SafeTagList safeTags;

    public static SafeTagList getSafeTags() {
        if (safeTags == null) {
            safeTags = new SafeTagList();
            safeTags.add(ClassModelTags.OBJECTS_TAG);
            safeTags.add(ClassModelTags.OBJECT_TAG);
            safeTags.add(ClassModelTags.CONSTRUCTOR_TAG);
            safeTags.add(ClassModelTags.ELEMENT_PROPERTY_TAG);
            safeTags.add(ClassModelTags.LOOKUP_PROPERTY_TAG);
            safeTags.add(ClassModelTags.ATTRIBUTE_PROPERTY_TAG);
            safeTags.add(ClassModelTags.PARAMETER_TAG);
            safeTags.add(ClassModelTags.INCLUDE_TAG);
            safeTags.add(ClassModelTags.IGNORED_PROPERTY_TAG);
            safeTags.add(ClassModelTags.MANUAL_TAG);
            safeTags.add(ClassModelTags.MAPPING_TAG);
            safeTags.add(ClassModelTags.TYPE_TAG);
        }
        return safeTags;
    }

    private XMLWriterSupport writerSupport;
    private DescriptionModel model;

    public ModelWriter() {
        writerSupport = new XMLWriterSupport(getSafeTags(), 0);
    }

    public DescriptionModel getModel() {
        return model;
    }

    public void setModel(DescriptionModel model) {
        this.model = model;
    }

    public static void writeXMLHeader(Writer writer) throws IOException {
        writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        writer.write(XMLWriterSupport.getLineSeparator());
    }

    protected void writeStandardComment(Writer writer, Comments comments) throws IOException {
        if ((comments == null) || (comments.getOpenTagComment() == null)) {
            writer.write("<!-- CVSTag: $Id: ModelWriter.java,v 1.8 2004/01/01 23:59:30 mungady Exp $ " + comments + " -->");
            writer.write(XMLWriterSupport.getLineSeparator());
        }
        else {
            writeComment(writer, comments.getOpenTagComment());
        }
    }

    protected void writeComment(Writer writer, String[] comments) throws IOException {
        if (comments == null) {
            return;
        }
        for (int i = 0; i < comments.length; i++) {
            writerSupport.indent(writer, XMLWriterSupport.INDENT_ONLY);
            writer.write("<!--");
            writer.write(comments[i]);
            writer.write("-->");
            writer.write(XMLWriterSupport.getLineSeparator());
        }
    }

    protected void writeOpenComment(Writer writer, Comments comments) throws IOException {
        if (comments == null) {
            return;
        }
        if (comments.getOpenTagComment() == null) {
            return;
        }
        writeComment(writer, comments.getOpenTagComment());
    }

    protected void writeCloseComment(Writer writer, Comments comments) throws IOException {
        if (comments == null) {
            return;
        }
        if (comments.getCloseTagComment() == null) {
            return;
        }
        writeComment(writer, comments.getCloseTagComment());
    }

    /**
     * Writes a closed (short) tag with eventually nested comments.
     *
     * @param writer
     * @param tagName
     * @param attributes
     * @param comments
     * @throws IOException
     */
    protected void writeTag (final Writer writer, final String tagName,
                           final AttributeList attributes,
                           final Comments comments)
        throws IOException
    {
        if (comments == null)
        {
            writerSupport.writeTag(writer, tagName, attributes, XMLWriterSupport.CLOSE);
        }
        else
        {
            writeOpenComment(writer, comments);
            if (comments.getCloseTagComment() != null)
            {
                writerSupport.writeTag(writer, tagName, attributes, XMLWriterSupport.OPEN);
                writeCloseComment(writer, comments);
                writerSupport.writeCloseTag(writer, tagName);
            }
            else
            {
                writerSupport.writeTag(writer, tagName, attributes, XMLWriterSupport.CLOSE);
            }
        }
    }

    /**
     * Writes a closed (short) tag with eventually nested comments.
     *
     * @param writer
     * @param tagName
     * @param attribute
     * @param value
     * @param comments
     * @throws IOException
     */
    protected void writeTag (final Writer writer, final String tagName,
                           final String attribute, final String value,
                           final Comments comments)
        throws IOException
    {
        if (comments == null)
        {
            writerSupport.writeTag(writer, tagName, attribute, value , XMLWriterSupport.CLOSE);
        }
        else
        {
            writeOpenComment(writer, comments);
            if (comments.getCloseTagComment() != null)
            {
                writerSupport.writeTag(writer, tagName, attribute, value , XMLWriterSupport.OPEN);
                writeCloseComment(writer, comments);
                writerSupport.writeCloseTag(writer, tagName);
            }
            else
            {
                writerSupport.writeTag(writer, tagName, attribute, value , XMLWriterSupport.CLOSE);
            }
        }
    }


    public void write(Writer writer) throws IOException {
        writeStandardComment(writer, model.getModelComments());
        writerSupport.writeTag(writer, ClassModelTags.OBJECTS_TAG);
        String[] sources = model.getSources();
        for (int i = 0; i < sources.length; i++) {
            Comments comments = model.getIncludeComment(sources[i]);
            writeTag(writer, ClassModelTags.INCLUDE_TAG, ClassModelTags.SOURCE_ATTR, sources[i], comments);
        }

        for (int i = 0; i < model.size(); i++) {
            ClassDescription cd = model.get(i);
            writeClassDescription(writer, cd);
        }

        ManualMappingInfo[] mappings = getModel().getMappingModel().getManualMapping();
        for (int i = 0; i < mappings.length; i++) {
            ManualMappingInfo mi = mappings[i];
            writeManualMapping(writer, mi);
        }

        MultiplexMappingInfo[] mmappings = getModel().getMappingModel().getMultiplexMapping();
        for (int i = 0; i < mmappings.length; i++) {
            MultiplexMappingInfo mi = mmappings[i];
            writeMultiplexMapping(writer, mi);
        }

        writeCloseComment(writer, model.getModelComments());
        writerSupport.writeCloseTag(writer, ClassModelTags.OBJECTS_TAG);
    }

    protected void writeManualMapping(Writer writer, ManualMappingInfo mi) throws IOException {

        AttributeList al = new AttributeList();
        al.setAttribute(ClassModelTags.CLASS_ATTR, mi.getBaseClass().getName());
        al.setAttribute(ClassModelTags.READ_HANDLER_ATTR, mi.getReadHandler().getName());
        al.setAttribute(ClassModelTags.WRITE_HANDLER_ATTR, mi.getWriteHandler().getName());
        writeTag(writer, ClassModelTags.MANUAL_TAG, al, mi.getComments());
    }

    protected void writeMultiplexMapping(Writer writer, MultiplexMappingInfo mi) throws IOException {
        TypeInfo[] tis = mi.getChildClasses();

        AttributeList al = new AttributeList();
        al.setAttribute(ClassModelTags.BASE_CLASS_ATTR, mi.getBaseClass().getName());
        al.setAttribute(ClassModelTags.TYPE_ATTR, mi.getTypeAttribute());
        getWriterSupport().writeTag(writer, ClassModelTags.MAPPING_TAG, al, XMLWriterSupport.OPEN);

        for (int j = 0; j < tis.length; j++) {
            AttributeList tiAttr = new AttributeList();
            tiAttr.setAttribute(ClassModelTags.NAME_ATTR, tis[j].getName());
            tiAttr.setAttribute(ClassModelTags.CLASS_ATTR, tis[j].getType().getName());
            writeTag(writer, ClassModelTags.TYPE_TAG, tiAttr, tis[j].getComments());
        }

        getWriterSupport().writeCloseTag(writer, ClassModelTags.MAPPING_TAG);
    }

    protected void writeClassDescription(Writer writer, ClassDescription cd)
        throws IOException {

        if (cd.isUndefined()) {
            return;
        }

        AttributeList al = new AttributeList();
        al.setAttribute(ClassModelTags.CLASS_ATTR, cd.getName());
        if (cd.getRegisterKey() != null) {
            al.setAttribute(ClassModelTags.REGISTER_NAMES_ATTR, cd.getRegisterKey());
        }
        if (cd.isPreserve()) {
            al.setAttribute(ClassModelTags.IGNORE_ATTR, "true");
        }
        writerSupport.writeTag(writer, ClassModelTags.OBJECT_TAG, al, XMLWriterSupport.OPEN);

        TypeInfo[] constructorInfo = cd.getConstructorDescription();
        if (constructorInfo != null && constructorInfo.length != 0) {
            writerSupport.writeTag(writer, ClassModelTags.CONSTRUCTOR_TAG);
            for (int i = 0; i < constructorInfo.length; i++) {
                AttributeList constructorList = new AttributeList();
                constructorList.setAttribute(ClassModelTags.CLASS_ATTR, constructorInfo[i].getType().getName());
                constructorList.setAttribute(ClassModelTags.PROPERTY_ATTR, constructorInfo[i].getName());
                writeTag(writer, ClassModelTags.PARAMETER_TAG, constructorList, constructorInfo[i].getComments());
            }
            writerSupport.writeCloseTag(writer, ClassModelTags.CONSTRUCTOR_TAG);
        }

        PropertyInfo[] properties = cd.getProperties();
        for (int i = 0; i < properties.length; i++) {
            writePropertyInfo(writer, properties[i]);
        }

        writerSupport.writeCloseTag(writer, ClassModelTags.OBJECT_TAG);
    }


    private void writePropertyInfo(Writer writer, PropertyInfo ipi)
        throws IOException {
        AttributeList props = new AttributeList();
        props.setAttribute(ClassModelTags.NAME_ATTR, ipi.getName());

        if (ipi instanceof IgnoredPropertyInfo) {
            writeTag(writer, ClassModelTags.IGNORED_PROPERTY_TAG, props, ipi.getComments());
            return;
        }

        if (ipi.getPropertyType().equals(PropertyType.ATTRIBUTE)) {
            props.setAttribute(ClassModelTags.ATTRIBUTE_ATTR, ipi.getXmlName());
            props.setAttribute(ClassModelTags.ATTRIBUTE_HANDLER_ATTR, ipi.getXmlHandler());
            writeTag(writer, ClassModelTags.ATTRIBUTE_PROPERTY_TAG, props, ipi.getComments());
        }
        else if (ipi.getPropertyType().equals(PropertyType.ELEMENT)) {
            if (ipi.getComments() == null || ipi.getComments().getOpenTagComment() == null)
            {
                writerSupport.indent(writer, XMLWriterSupport.INDENT_ONLY);
                writer.write("<!-- property type is " + ipi.getType() + " -->");
                writer.write(System.getProperty("line.separator", "\n"));
            }
            props.setAttribute(ClassModelTags.ELEMENT_ATTR, ipi.getXmlName());
            writeTag(writer, ClassModelTags.ELEMENT_PROPERTY_TAG, props, ipi.getComments());
        }
        else {
            props.setAttribute(ClassModelTags.LOOKUP_ATTR, ipi.getXmlName());
            writeTag(writer, ClassModelTags.LOOKUP_PROPERTY_TAG, props, ipi.getComments());
        }
    }

    public XMLWriterSupport getWriterSupport() {
        return writerSupport;
    }
}
