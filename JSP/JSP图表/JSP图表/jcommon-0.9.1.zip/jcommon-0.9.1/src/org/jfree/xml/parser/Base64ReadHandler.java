package org.jfree.xml.parser;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import org.jfree.xml.util.Base64;
import org.xml.sax.SAXException;

/**
 * @deprecated base64 encoded elements are no longer supported ...
 */
public class Base64ReadHandler extends AbstractXmlReadHandler {
    private String encodedObject;
    
    public Base64ReadHandler() {
    }

    public void characters(char[] ch, int start, int length)
        throws SAXException {
        this.encodedObject = new String(ch, start, length);
    }

    public Object getObject() throws XmlReaderException {
        try {
            byte[] bytes = Base64.decode(this.encodedObject.toCharArray());
            ObjectInputStream in =
                new ObjectInputStream(new ByteArrayInputStream(bytes));
            return in.readObject();
        } catch (IOException e) {
            throw new XmlReaderException("Can't read class for <" + getTagName() + ">", e);
        } catch (ClassNotFoundException e) {
            throw new XmlReaderException("Class not found for <" + getTagName() + ">", e);
        }
    }
}
