/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ---------------
 * FontReadHandler
 * ---------------
 * (C) Copyright 2003, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: FontReadHandler.java,v 1.4 2004/01/01 23:59:26 mungady Exp $
 *
 * Changes (from 25-Nov-2003)
 * --------------------------
 * 25-Nov-2003 : Added standard header and Javadocs (DG);
 *
 */

package org.jfree.xml.parser.coretypes;

import java.awt.Font;

import org.jfree.xml.parser.AbstractXmlReadHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * A SAX handler for reading a font definition.
 */
public class FontReadHandler extends AbstractXmlReadHandler  {
    
    /** The font under construction. */
    private Font font;

    /**
     * Creates a new SAX handler for reading a {@link Font} from XML.
     */
    public FontReadHandler() {
    }

    /**
     * Called at the start of parsing a font element, this method reads the attributes and
     * constructs the font. 
     */
    protected void startParsing(Attributes attrs) throws SAXException {
        String family = attrs.getValue("family");
        int size = Integer.parseInt(attrs.getValue("size"));
        int style = getFontStyle(attrs.getValue("style"));
        this.font = new Font(family, style, size);
    }

    private int getFontStyle (String style)
    {
        if ("bold-italic".equals(style))
        {
            return Font.BOLD | Font.ITALIC;
        }
        if ("bold".equals(style))
        {
            return Font.BOLD;
        }
        if ("italic".equals(style))
        {
            return Font.ITALIC;
        }
        return Font.PLAIN;
    }

    /**
     * Returns the font under construction.
     * 
     * @return the font.
     */
    public Object getObject() {
        return this.font;
    }
    
}
