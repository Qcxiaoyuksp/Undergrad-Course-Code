/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * -------------------------
 * GenericObjectFactory.java
 * -------------------------
 * (C)opyright 2003, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: GenericObjectFactory.java,v 1.8 2004/01/01 23:59:29 mungady Exp $
 *
 * Changes
 * -------------------------
 * 23.09.2003 : Initial version
 *
 */

package org.jfree.xml.util;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.HashMap;

/**
 * The generic object factory contains all methods necessary to collect
 * the property values needed to produce a fully instantiated object.
 */
public final class GenericObjectFactory {

    /** Storage for the constructor definitions. */
    private final ConstructorDefinition[] constructorDefinitions;
    
    /** Storage for the property definitions. */
    private final PropertyDefinition[] propertyDefinitions;
    
    /** Storage for the lookup definitions. */
    private final LookupDefinition[] lookupDefinitions;
    
    /** Storage for the attribute definitions. */
    private final AttributeDefinition[] attributeDefinitions;
    
    /** The ordered property names. */
    private final String[] orderedPropertyNames;

    /** Storage for property info. */
    private final HashMap propertyInfos;
    
    /** Storage for property values. */
    private final HashMap propertyValues;

    /** The base class. */
    private final Class baseClass;
    
    /** The register name. */
    private final String registerName;

    /**
     * Creates a new generic object factory.
     * 
     * @param c  the class.
     * @param registerName the (optional) name under which to register the class for
     *                     any later lookup.
     * @param constructors  the constructor definitions.
     * @param propertyDefinitions  the property definitions.
     * @param lookupDefinitions  the lookup definitions.
     * @param attributeDefinitions  the attribute definitions.
     * @param orderedPropertyNames  the ordered property names.
     * 
     * @throws ObjectDescriptionException if there is a problem.
     */
    public GenericObjectFactory(final Class c, 
                                final String registerName,
                                final ConstructorDefinition[] constructors,
                                final PropertyDefinition[] propertyDefinitions,
                                final LookupDefinition[] lookupDefinitions,
                                final AttributeDefinition[] attributeDefinitions,
                                final String[] orderedPropertyNames)
        throws ObjectDescriptionException {

        if (c == null) {
            throw new NullPointerException("BaseClass cannot be null.");
        }
        baseClass = c;
        this.registerName = registerName;

        this.propertyInfos = new HashMap();
        this.propertyValues = new HashMap();

        this.constructorDefinitions = constructors;
        this.propertyDefinitions = propertyDefinitions;
        this.lookupDefinitions = lookupDefinitions;
        this.attributeDefinitions = attributeDefinitions;
        this.orderedPropertyNames = orderedPropertyNames;

        try {
            BeanInfo chartBeaninfo = Introspector.getBeanInfo(c, Object.class);
            PropertyDescriptor[] pd = chartBeaninfo.getPropertyDescriptors();
            for (int i = 0; i < pd.length; i++) {
                propertyInfos.put(pd[i].getName(), pd[i]);
            }
        }
        catch (IntrospectionException ioe) {
            throw new ObjectDescriptionException("This is an ugly solution right now ... dirty hack attack");
        }
    }

    /**
     * A copy constructor.
     * 
     * @param factory  the factory to copy.
     */
    private GenericObjectFactory (GenericObjectFactory factory) {
        this.baseClass = factory.baseClass;
        this.propertyValues = new HashMap();
        this.orderedPropertyNames = factory.orderedPropertyNames;
        this.constructorDefinitions = factory.constructorDefinitions;
        this.propertyDefinitions = factory.propertyDefinitions;
        this.attributeDefinitions = factory.attributeDefinitions;
        this.propertyInfos = factory.propertyInfos;
        this.registerName = factory.registerName;
        this.lookupDefinitions = factory.lookupDefinitions;
    }

    /**
     * Returns a copy of this instance.
     * 
     * @return a copy of this instance.
     */
    public GenericObjectFactory getInstance () {
        return new GenericObjectFactory(this);
    }

    /**
     * Returns the register name.
     * 
     * @return the register name.
     */
    public String getRegisterName() {
        return registerName;
    }

    /**
     * Returns a property descriptor.
     * 
     * @param propertyName  the property name.
     * 
     * @return a property descriptor.
     */
    private PropertyDescriptor getPropertyDescriptor(String propertyName) {
        return (PropertyDescriptor) propertyInfos.get(propertyName);
    }

    public Class getTypeForTagName(String tagName) throws ObjectDescriptionException {
        PropertyDefinition pdef = getPropertyDefinitionByTagName(tagName);
        PropertyDescriptor pdescr = getPropertyDescriptor(pdef.getPropertyName());
        if (pdescr == null) {
            throw new ObjectDescriptionException("Invalid Definition: " + pdef.getPropertyName());
        }
        return pdescr.getPropertyType();
    }

    public boolean isPropertyDefinition (String propertyName)
    {
        for (int i = 0; i < propertyDefinitions.length; i++) {
            PropertyDefinition pdef = propertyDefinitions[i];
            if (pdef.getPropertyName().equals(propertyName)) {
                return true;
            }
        }
        return false;
    }

    public PropertyDefinition getPropertyDefinitionByPropertyName(String propertyName)
        throws ObjectDescriptionException {
        for (int i = 0; i < propertyDefinitions.length; i++) {
            PropertyDefinition pdef = propertyDefinitions[i];
            if (pdef.getPropertyName().equals(propertyName)) {
                return pdef;
            }
        }
        throw new ObjectDescriptionException("This property is not defined for this kind of object. : " + propertyName);
    }

    public PropertyDefinition getPropertyDefinitionByTagName(String tagName)
        throws ObjectDescriptionException {
        for (int i = 0; i < propertyDefinitions.length; i++) {
            PropertyDefinition pdef = propertyDefinitions[i];
            if (pdef.getElementName().equals(tagName)) {
                return pdef;
            }
        }
        throw new ObjectDescriptionException("This tag is not defined for this kind of object. : " + tagName);
    }

    /**
     * Returns the constructor definitions.
     * 
     * @return the constructor definitions.
     */
    public ConstructorDefinition[] getConstructorDefinitions() {
        return constructorDefinitions;
    }

    public AttributeDefinition[] getAttributeDefinitions() {
        return attributeDefinitions;
    }

    public PropertyDefinition[] getPropertyDefinitions() {
        return propertyDefinitions;
    }

    public String[] getOrderedPropertyNames() {
        return orderedPropertyNames;
    }

    public LookupDefinition[] getLookupDefinitions() {
        return lookupDefinitions;
    }

    public Object getProperty(String name) {
        return propertyValues.get(name);
    }

    public Object createObject() throws ObjectDescriptionException {
        Class[] cArgs = new Class[constructorDefinitions.length];
        Object[] oArgs = new Object[constructorDefinitions.length];
        for (int i = 0; i < cArgs.length; i++) {
            ConstructorDefinition cDef = constructorDefinitions[i];
            cArgs[i] = cDef.getType();
            if (cDef.isNull()) {
                oArgs[i] = null;
            }
            else {
                oArgs[i] = getProperty(cDef.getPropertyName());
            }
        }

        try {
            Constructor constr = baseClass.getConstructor(cArgs);
            Object o = constr.newInstance(oArgs);
            return o;
        }
        catch (Exception e) {
            throw new ObjectDescriptionException("Ugh! Constructor made a buuuh!", e);
        }
    }

    public void setProperty(String propertyName, Object value)
        throws ObjectDescriptionException {
        PropertyDescriptor pdesc = getPropertyDescriptor(propertyName);
        if (pdesc == null) {
            throw new ObjectDescriptionException("Unknown property " + propertyName);
        }

        if (isAssignableOrPrimitive(pdesc.getPropertyType(), value.getClass()) == false) {
            throw new ObjectDescriptionException("Invalid value: " + pdesc.getPropertyType() + " vs. " + value.getClass());
        }

        propertyValues.put(propertyName, value);
    }

    private boolean isAssignableOrPrimitive(Class baseType, Class valueType) {
        if (BasicTypeSupport.isBasicDataType(baseType))
        {
            return true;
        }
        // verbose stuff below *should* no longer be needed
        return baseType.isAssignableFrom(valueType);
    }

    private boolean isConstructorProperty(String propertyName) {
        for (int i = 0; i < constructorDefinitions.length; i++) {
            ConstructorDefinition cDef = constructorDefinitions[i];
            if (propertyName.equals(cDef.getPropertyName())) {
                return true;
            }
        }
        return false;
    }

    public void writeObjectProperties(Object object) throws ObjectDescriptionException {
        // this assumes that the order of setting the attributes does not matter.
        for (int i = 0; i < orderedPropertyNames.length; i++) {
            try {
                String name = orderedPropertyNames[i];
                if (isConstructorProperty(name)) {
                    continue;
                }
                Object value = getProperty(name);
                if (value == null) {
                    // do nothing if value is not defined ...
                    // System.out.println("Value for key " + name + " is null.");
                    continue;
                }
                // System.out.println("Value for key " + name + " is " + value);
                PropertyDescriptor pdescr = getPropertyDescriptor(name);
                Method setter = pdescr.getWriteMethod();
                setter.invoke(object, new Object[]{value});
            }
            catch (Exception e) {
                throw new ObjectDescriptionException("Failed to set properties." + getBaseClass(), e);
            }
        }
    }

    // lookup definitions are not filled here
    public void readProperties(Object object) throws ObjectDescriptionException {
        // this assumes that the order of setting the attributes does not matter.
        for (int i = 0; i < orderedPropertyNames.length; i++) {
            try {
                String name = orderedPropertyNames[i];
                PropertyDescriptor pdescr = getPropertyDescriptor(name);
                if (pdescr == null)
                {
                    throw new IllegalStateException("No property defined: "+ name);
                }
                Method setter = pdescr.getReadMethod();
                Object value = setter.invoke(object, new Object[0]);
                if (value == null) {
                    // do nothing if value is not defined ... or null
                    // System.out.println("Value for key " + name + " is null - ignore it.");
                    continue;
                }
                setProperty(name, value);
            }
            catch (Exception e) {
                throw new ObjectDescriptionException("Failed to set properties.", e);
            }
        }
    }

    /**
     * Returns the base class.
     * 
     * @return the base class.
     */
    public Class getBaseClass() {
        return baseClass;
    }
    
}
