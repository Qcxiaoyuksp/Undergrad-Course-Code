# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
 
data = pd.read_csv("历史数据.csv",encoding="GBK")
#%%
tra_sex = {"F":0,"M":1}
tra_blood = {"HIGH":2,"LOW":0,"NORMAL":1}
tra_cho = {"HIGH":1,"NORMAL":0}
tra_drug = {"drugA":0,"drugB":1,"drugC":2,"drugX":3,"drugY":4}
 
data.性别 = data.性别.map(tra_sex)
data.血压 = data.血压.map(tra_blood)
data.胆固醇 = data.胆固醇.map(tra_cho)
data.药物 = data.药物.map(tra_drug)
#%%
x_data = data[["性别","年龄","血压","胆固醇","钠含量","钾含量"]]
y_data = data["药物"]
 
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test = train_test_split(x_data,y_data,test_size = 0.3,random_state = 1)
#%%
from sklearn import tree

clf1 = tree.DecisionTreeClassifier(random_state = 1)#决策树
model_result = clf1.fit(x_train,y_train)
 
#%%
predicts = model_result.predict(x_test)  #代入测试集
accuracy = sum(predicts == y_test)/len(y_test) #计算准确度
 
print("决策树模型测试集准确度:%.2f\n"%(accuracy))
from sklearn import metrics
print("决策树模型性能报告\n",metrics.classification_report(y_test, predicts))
#%%
# 给新病人开药
newdata=pd.read_csv("新数据.csv",index_col=0,encoding="GBK")
newdata.性别 = newdata.性别.map(tra_sex)
newdata.血压 = newdata.血压.map(tra_blood)
newdata.胆固醇 = newdata.胆固醇.map(tra_cho)
newpredicts = model_result.predict(newdata)  #代入测试集
#%% 结果转换为药名
tra_drug2 = {0:"drugA",1:"drugB",2:"drugC",3:"drugX",4:"drugY"}
ret=pd.Series(newpredicts.tolist()).map(tra_drug2)
ret.name='AI药方'
#%%
ret.index=list(range(1,11))
df2=newdata.join(ret)
df2.to_csv('AI开药结果.csv',mode='w',encoding="GBK")
#%%
import matplotlib.pyplot as plt
plt.figure(figsize=(18,12))
tree.plot_tree(clf1,filled = True)
# plt.show()
plt.savefig('tree.jpg', dpi=300)

#%% 生成dot文件后转为png、pdf
with open('tree.dot', 'w') as dot_file:
    tree.export_graphviz(clf1, out_file=dot_file)
# 命令行 dot -Tpng tree.dot -o tree.png
# 命令行 dot -Tpdf tree.dot -o tree.pdf