/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * -------------------------
 * MultiplexMappingInfo.java
 * -------------------------
 * (C)opyright 2003, 2004, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Simba Management Limited);
 *
 * $Id: MultiplexMappingInfo.java,v 1.3 2004/01/01 23:59:31 mungady Exp $
 *
 * Changes 
 * -------------------------
 * 16.11.2003 : Initial version
 *  
 */

package org.jfree.xml.generator.model;

import java.util.Arrays;

/**
 * Defines the multiplex entries for a certain base class. Multiplexers are
 * used to select a specific handler if more than one class will match the
 * property type.
 * <p>
 * Multiplexers override automatic mappings and can be redefined using manual
 * mappings.
 */
public class MultiplexMappingInfo {
    private Class baseClass;
    private String typeAttribute;
    private TypeInfo[] childClasses;
    private Comments comments;
    private String source;

    public MultiplexMappingInfo(Class baseClass) {
        this(baseClass, "type");
    }

    public MultiplexMappingInfo(Class baseClass, String typeAttribute) {
        if (baseClass == null)
        {
            throw new NullPointerException("BaseClass");
        }
        if (typeAttribute == null)
        {
            throw new NullPointerException("TypeAttribute");
        }
        this.baseClass = baseClass;
        this.typeAttribute = typeAttribute;
    }

    public Class getBaseClass() {
        return baseClass;
    }

    public String getTypeAttribute() {
        return typeAttribute;
    }

    public TypeInfo[] getChildClasses() {
        return childClasses;
    }

    public void setChildClasses(TypeInfo[] childClasses) {
        this.childClasses = childClasses;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof MultiplexMappingInfo)) return false;

        final MultiplexMappingInfo multiplexMappingInfo = (MultiplexMappingInfo) o;

        if (!baseClass.equals(multiplexMappingInfo.baseClass)) return false;
        if (!Arrays.equals(childClasses, multiplexMappingInfo.childClasses)) return false;
        if (!typeAttribute.equals(multiplexMappingInfo.typeAttribute)) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = baseClass.hashCode();
        result = 29 * result + typeAttribute.hashCode();
        return result;
    }

    public Comments getComments() {
        return comments;
    }

    public void setComments(Comments comments) {
        this.comments = comments;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
}
