/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ------------------------------
 * RenderingHintsReadHandler.java
 * ------------------------------
 * (C)opyright 2003, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Simba Management Limited);
 *
 * $Id: RenderingHintsReadHandler.java,v 1.2 2004/01/01 23:59:26 mungady Exp $
 *
 * Changes
 * -------------------------
 * 03.12.2003 : Initial version
 *
 */

package org.jfree.xml.parser.coretypes;

import java.util.ArrayList;
import java.awt.RenderingHints;

import org.jfree.xml.parser.AbstractXmlReadHandler;
import org.jfree.xml.parser.XmlReaderException;
import org.jfree.xml.parser.XmlReadHandler;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;

public class RenderingHintsReadHandler extends AbstractXmlReadHandler {

    private ArrayList handlers;
    private RenderingHints renderingHints;

    public RenderingHintsReadHandler() {
    }

    /**
     * Starts parsing.
     *
     * @param attrs  the attributes.
     *
     * @throws SAXException if there is a parsing error.
     */
    protected void startParsing(Attributes attrs) throws SAXException {
        handlers = new ArrayList();
    }

    /**
     * Returns the handler for a child element.
     *
     * @param tagName  the tag name.
     *
     * @return the handler.
     *
     * @throws SAXException  if there is a parsing error.
     */
    protected XmlReadHandler getHandlerForChild(String tagName, Attributes atts)
        throws XmlReaderException, SAXException {

        if (tagName.equals("entry") == false) {
            throw new SAXException("Expected 'entry' tag.");
        }

        XmlReadHandler handler = new RenderingHintValueReadHandler();
        handlers.add(handler);
        return handler;
    }

    /**
     * Done parsing.
     *
     * @throws SAXException if there is a parsing error.
     */
    protected void doneParsing() throws SAXException, XmlReaderException {
        renderingHints = new RenderingHints(null);

        for (int i = 0; i < handlers.size(); i++) {
            RenderingHintValueReadHandler rh =
                (RenderingHintValueReadHandler) handlers.get(i);
            renderingHints.put(rh.getKey(), rh.getValue());
        }
    }

    /**
     * Returns the object for this element.
     *
     * @return the object.
     *
     * @throws XmlReaderException if there is a parsing error.
     */
    public Object getObject() throws XmlReaderException {
        return renderingHints;
    }
}
