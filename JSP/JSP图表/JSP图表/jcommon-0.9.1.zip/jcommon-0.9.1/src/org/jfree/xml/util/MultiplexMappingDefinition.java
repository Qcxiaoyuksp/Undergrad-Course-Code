/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ------------------------------
 * MultiplexMappingDefinition.java
 * ------------------------------
 * (C)opyright 2003, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Simba Management Limited);
 *
 * $Id: MultiplexMappingDefinition.java,v 1.2 2004/01/01 23:59:29 mungady Exp $
 *
 * Changes 
 * -------------------------
 * 22.11.2003 : Initial version
 *  
 */

package org.jfree.xml.util;

import java.util.HashMap;

public class MultiplexMappingDefinition {

    private Class baseClass;
    private String attributeName;
    private HashMap forwardMappings;
    private HashMap reverseMappings;

    public MultiplexMappingDefinition
        (Class baseClass, String attributeName, MultiplexMappingEntry[] entries) {
        this.attributeName = attributeName;
        this.baseClass = baseClass;
        this.forwardMappings = new HashMap();
        this.reverseMappings = new HashMap();

        for (int i = 0; i < entries.length; i++)
        {
            MultiplexMappingEntry entry = entries[i];
            forwardMappings.put(entry.getAttributeValue(), entry);
            reverseMappings.put(entry.getTargetClass(), entry);
        }
    }

    public String getAttributeName() {
        return attributeName;
    }

    public Class getBaseClass() {
        return baseClass;
    }

    public MultiplexMappingEntry getEntryForType (String type)
    {
        return (MultiplexMappingEntry) forwardMappings.get(type);
    }

    public MultiplexMappingEntry getEntryForClass (String clazz)
    {
        return (MultiplexMappingEntry) reverseMappings.get(clazz);
    }
}
