/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * -------------------------
 * SplittingModelWriter.java
 * -------------------------
 * (C)opyright 2003, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: SplittingModelWriter.java,v 1.5 2004/01/01 23:59:30 mungady Exp $
 *
 * Changes
 * -------------------------
 * 12.11.2003 : Initial version
 *
 */

package org.jfree.xml.generator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import org.jfree.io.IOUtils;
import org.jfree.util.HashNMap;
import org.jfree.util.Log;
import org.jfree.xml.generator.model.ClassDescription;
import org.jfree.xml.generator.model.DescriptionModel;
import org.jfree.xml.generator.model.ManualMappingInfo;
import org.jfree.xml.generator.model.MultiplexMappingInfo;
import org.jfree.xml.generator.model.MappingModel;
import org.jfree.xml.util.ClassModelTags;

public class SplittingModelWriter extends ModelWriter {

    private HashNMap classDescriptionByPackage;
    private ArrayList sources;
    private File targetFile;
    private String extension;
    private String plainFileName;
    private HashNMap manualMappingByPackage;
    private HashNMap multiplexMappingByPackage;

    public SplittingModelWriter() {
    }


    public synchronized void write(String target) throws IOException {
        DescriptionModel model = getModel();

        sources = new ArrayList(Arrays.asList(model.getSources()));
        targetFile = new File(target);
        plainFileName = IOUtils.getInstance().stripFileExtension(targetFile.getName());
        extension = IOUtils.getInstance().getFileExtension(target);

        // split into classDescriptionByPackage ...
        classDescriptionByPackage = new HashNMap();
        for (int i = 0; i < model.size(); i++) {
            final ClassDescription cd = model.get(i);
            if (cd.getSource() == null) {
                final String packageName = getPackage(cd.getObjectClass());
                final String includeFileName = plainFileName + "-" + packageName + extension;
                classDescriptionByPackage.add(includeFileName, cd);
            }
            else {
                classDescriptionByPackage.add(cd.getSource(), cd);
            }
        }

        MappingModel mappingModel = model.getMappingModel();

        // split manual mappings into packages ...
        ManualMappingInfo[] manualMappings = mappingModel.getManualMapping();
        manualMappingByPackage = new HashNMap();
        for (int i = 0; i < manualMappings.length; i++) {
            final ManualMappingInfo mapping = manualMappings[i];
            if (mapping.getSource() == null) {
                manualMappingByPackage.add("", mapping);
            }
            else {
                manualMappingByPackage.add(mapping.getSource(), mapping);
            }
        }

        // split manual mappings into packages ...
        MultiplexMappingInfo[] multiplexMappings = mappingModel.getMultiplexMapping();
        multiplexMappingByPackage = new HashNMap();
        for (int i = 0; i < multiplexMappings.length; i++) {
            final MultiplexMappingInfo mapping = multiplexMappings[i];
            if (mapping.getSource() == null) {
                multiplexMappingByPackage.add("", mapping);
            }
            else {
                multiplexMappingByPackage.add(mapping.getSource(), mapping);
            }
        }


        Object[] keys = classDescriptionByPackage.keySet().toArray();
        for (int i = 0; i < keys.length; i++) {

            final String includeFileName = (String) keys[i];
            // write if not contained in the master file ...
            if (includeFileName.equals("") == false) {
                writePackageFile(includeFileName);
            }
        }

        writeMasterFile();

        manualMappingByPackage = null;
        multiplexMappingByPackage = null;
        classDescriptionByPackage = null;
        sources = null;
    }

    private void writePackageFile(String includeFileName)
        throws IOException, FileNotFoundException {
        Iterator values = classDescriptionByPackage.getAll(includeFileName);
        Iterator manualMappings = manualMappingByPackage.getAll(includeFileName);
        Iterator multiplexMappings = multiplexMappingByPackage.getAll(includeFileName);
        if ((values.hasNext() == false) &&
            (manualMappings.hasNext() == false) &&
            (multiplexMappings.hasNext() == false)) {
            return;
        }

        Log.debug ("Writing included file: " + includeFileName);
        // the current file need no longer be included manually ...
        sources.remove(includeFileName);

        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter
            (new FileOutputStream(new File(targetFile.getParentFile(), includeFileName)), "UTF-8"));

        writeXMLHeader(writer);
        writeStandardComment(writer, getModel().getModelComments());
        getWriterSupport().writeTag(writer, ClassModelTags.OBJECTS_TAG);

        while (values.hasNext()) {
            ClassDescription cd = (ClassDescription) values.next();
            writeClassDescription(writer, cd);
        }


        while (manualMappings.hasNext()) {
            ManualMappingInfo mi = (ManualMappingInfo) manualMappings.next();
            writeManualMapping(writer, mi);
        }

        while (multiplexMappings.hasNext()) {
            MultiplexMappingInfo mi = (MultiplexMappingInfo) multiplexMappings.next();
            writeMultiplexMapping(writer, mi);
        }

        writeCloseComment(writer, getModel().getModelComments());
        getWriterSupport().writeCloseTag(writer, ClassModelTags.OBJECTS_TAG);
        writer.close();
    }

    /**
     * Returns the name of the package for the given class. This is a
     * workaround for the classloader behaviour of JDK1.2.2 where no
     * package objects are created.
     *
     * @param c the class for which we search the package.
     * @return the name of the package, never null.
     */
    public static String getPackage(final Class c) {
        final String className = c.getName();
        final int idx = className.lastIndexOf('.');
        if (idx <= 0) {
            // the default package
            return "";
        }
        else {
            return className.substring(0, idx);
        }
    }

    private void writeMasterFile()
        throws IOException {

        Log.debug ("Writing master file: " + targetFile);

        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter
            (new FileOutputStream(targetFile), "UTF-8"));

        writeXMLHeader(writer);
        writeStandardComment(writer, getModel().getModelComments());
        getWriterSupport().writeTag(writer, ClassModelTags.OBJECTS_TAG);

        for (int i = 0; i < sources.size(); i++) {
            String includeFileName = (String) sources.get(i);
            if (includeFileName.equals("") == false) {
                writeTag(writer, ClassModelTags.INCLUDE_TAG, ClassModelTags.SOURCE_ATTR,
                    includeFileName, getModel().getIncludeComment(includeFileName));
            }
        }

        Object[] keys = classDescriptionByPackage.keySet().toArray();
        Arrays.sort(keys);
        for (int i = 0; i < keys.length; i++) {
            String includeFileName = (String) keys[i];
            if (includeFileName.equals("") == false) {
                writeTag(writer, ClassModelTags.INCLUDE_TAG, ClassModelTags.SOURCE_ATTR,
                    includeFileName, getModel().getIncludeComment(includeFileName));
            }
        }

        Iterator values = classDescriptionByPackage.getAll("");
        while (values.hasNext()) {
            ClassDescription cd = (ClassDescription) values.next();
            writeClassDescription(writer, cd);
        }

        Iterator manualMappings = manualMappingByPackage.getAll("");
        while (manualMappings.hasNext()) {
            ManualMappingInfo mi = (ManualMappingInfo) manualMappings.next();
            writeManualMapping(writer, mi);
        }

        Iterator multiplexMappings = multiplexMappingByPackage.getAll("");
        while (multiplexMappings.hasNext()) {
            MultiplexMappingInfo mi = (MultiplexMappingInfo) multiplexMappings.next();
            writeMultiplexMapping(writer, mi);
        }

        writeCloseComment(writer, getModel().getModelComments());
        getWriterSupport().writeCloseTag(writer, ClassModelTags.OBJECTS_TAG);
        writer.close();
    }
}
