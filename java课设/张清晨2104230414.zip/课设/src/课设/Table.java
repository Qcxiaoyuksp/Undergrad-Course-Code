package ����;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Table extends JFrame {
	private JPanel contentPane;
	/**
	 *����Ӧ�ó���
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Table frame = new Table();
					frame.setVisible(true);
				} 
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 *�������
	 */
	public Table() {
		setTitle("Choice");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(750,350,450,300);//�����С
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);//��屳����ɫ
		contentPane.setForeground(Color.WHITE);//���ǰ����ɫ
		contentPane.setBorder(new EmptyBorder(5,5,5,5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		/**
		 *���ý������
		 */
		JTextArea txtrYouWant = new JTextArea();
		txtrYouWant.setBackground(SystemColor.menu);
		txtrYouWant.setFont(new Font("����",Font.PLAIN,21));
		txtrYouWant.setEditable(false);
		txtrYouWant.setText("Please click your choice");
		txtrYouWant.setBounds(80,45,265,30);
		contentPane.add(txtrYouWant);
		/**
		 *����Add��ť
		 */
		JButton btnAdd = new JButton("Add product");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Add frame = new Add();
				frame.setVisible(true);
			}
		});
		btnAdd.setBounds(30,125,150,30);
		contentPane.add(btnAdd);
		/**
		 *����Delete��ť
		 */
		JButton btnDelete = new JButton("Delete product");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Delete frame = new Delete();
				frame.setVisible(true);
			}
		});
		btnDelete.setBounds(250,125,150,30);
		contentPane.add(btnDelete);
		/**
		 *����Update��ť
		 */
		JButton btnUpdate = new JButton("Update product");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Update frame = new Update();
				frame.setVisible(true);
			}
		});
		btnUpdate.setBounds(30,180,150,30);
		contentPane.add(btnUpdate);
		/**
		 *����Find��ť
		 */
		JButton btnFind = new JButton("Find product");
		btnFind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Find frame = new Find();
				frame.setVisible(true);
			}
		});
		btnFind.setBounds(250,180,150,30);
		contentPane.add(btnFind);
	}
}