/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * -------------
 * TypeInfo.java
 * -------------
 * (C)opyright 2003, 2004, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: TypeInfo.java,v 1.5 2004/01/01 23:59:31 mungady Exp $
 *
 * Changes 
 * -------------------------
 * 21.06.2003 : Initial version
 *  
 */

package org.jfree.xml.generator.model;

public class TypeInfo {
    private String name;
    private Class type;
    private boolean nullable;
    private boolean constrained;
    private String description;
    private Comments comments;

    public TypeInfo(String name, Class type) {
        if (name == null)
        {
            throw new NullPointerException("Name");
        }
        this.name = name;
        this.type = type;
    }

    public Class getType() {
        return type;
    }

    public boolean isNullable() {
        return nullable;
    }

    public void setNullable(boolean nullable) {
        this.nullable = nullable;
    }

    public boolean isConstrained() {
        return constrained;
    }

    public void setConstrained(boolean constrained) {
        this.constrained = constrained;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TypeInfo)) return false;

        final TypeInfo typeInfo = (TypeInfo) o;

        if (!name.equals(typeInfo.name)) return false;
        if (!type.equals(typeInfo.type)) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = name.hashCode();
        result = 29 * result + type.hashCode();
        result = 29 * result + (nullable ? 1 : 0);
        result = 29 * result + (constrained ? 1 : 0);
        result = 29 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

    public Comments getComments() {
        return comments;
    }

    public void setComments(Comments comments) {
        this.comments = comments;
    }
}
