/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ------------
 * ObjectFactoryLoader.java
 * ------------
 * (C) Copyright 2002, 2003, by Object Refinery Limited.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   -;
 *
 * $Id: ObjectFactoryLoader.java,v 1.7 2004/01/01 23:59:29 mungady Exp $
 *
 * Changes
 * -------
 * 24-Sep-2003: Initial version
 *
 */

package org.jfree.xml.util;

import java.net.URL;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Arrays;

import org.jfree.util.Log;
import org.jfree.xml.attributehandlers.AttributeHandler;

/**
 * The object factory loader loads the xml specification for the generic
 * handlers. The specification may be distributed over multiple files.
 * <p>
 * This class provides the model management for the reader and writer.
 * The instantiation of the handlers is done elsewhere.
 *
 * @author TM
 */
public class ObjectFactoryLoader extends AbstractModelReader implements ObjectFactory {

    /** Maps classes to GenericObjectFactory instances. */
    private HashMap objectMappings;
    
    /** Manual mappings. */
    private HashMap manualMappings;
    
    /** Multiplex mappings. */
    private HashMap multiplexMappings;

    /** The target class. */
    private Class target;
    
    /** The register name. */
    private String registerName;
    
    /** The property definition. */
    private ArrayList propertyDefinition;
    
    /** The attribute definition. */
    private ArrayList attributeDefinition;
    
    /** The constructor definition. */
    private ArrayList constructorDefinition;
    
    /** The lookup definitions. */
    private ArrayList lookupDefinitions;
    
    /** The ordered names. */
    private ArrayList orderedNames;

    /** The base class. */
    private String baseClass;
    
    /** The attribute name. */
    private String attributeName;
    
    /** The multiplex entries. */
    private ArrayList multiplexEntries;

    /**
     * Creates a new object factory loader for the given base file.
     *
     * @param resourceName the URL of the initial specification file.
     * 
     * @throws ObjectDescriptionException if the file could not be parsed.
     */
    public ObjectFactoryLoader(URL resourceName) throws ObjectDescriptionException {
        this.objectMappings = new HashMap();
        this.manualMappings = new HashMap();
        this.multiplexMappings = new HashMap();
        parseXml(resourceName);
        rebuildSuperClasses();
    }

    private void rebuildSuperClasses() throws ObjectDescriptionException {
        propertyDefinition = new ArrayList();
        attributeDefinition = new ArrayList();
        constructorDefinition = new ArrayList();
        lookupDefinitions = new ArrayList();
        orderedNames = new ArrayList();

        HashMap newObjectDescriptions = new HashMap();
        Iterator it = objectMappings.keySet().iterator();
        while (it.hasNext()) {
            Object key = it.next();
            GenericObjectFactory gef = (GenericObjectFactory) objectMappings.get(key);
            performSuperClassUpdate(gef);

            final PropertyDefinition[] propertyDefs = (PropertyDefinition[])
                propertyDefinition.toArray(new PropertyDefinition[0]);
            final LookupDefinition[] lookupDefs = (LookupDefinition[])
                lookupDefinitions.toArray(new LookupDefinition[0]);
            final AttributeDefinition[] attribDefs = (AttributeDefinition[])
                attributeDefinition.toArray(new AttributeDefinition[0]);
            final ConstructorDefinition[] constructorDefs = (ConstructorDefinition[])
                constructorDefinition.toArray(new ConstructorDefinition[0]);
            final String[] orderedNamesDefs = (String[])
                orderedNames.toArray(new String[0]);

            GenericObjectFactory objectFactory = new GenericObjectFactory
                (gef.getBaseClass(), gef.getRegisterName(), constructorDefs,
                    propertyDefs, lookupDefs, attribDefs, orderedNamesDefs);
            newObjectDescriptions.put(key, objectFactory);

            propertyDefinition.clear();
            attributeDefinition.clear();
            constructorDefinition.clear();
            lookupDefinitions.clear();
            orderedNames.clear();
        }

        this.objectMappings.clear();
        this.objectMappings = newObjectDescriptions;

        propertyDefinition = null;
        attributeDefinition = null;
        constructorDefinition = null;
        lookupDefinitions = null;
        orderedNames = null;
    }

    private void performSuperClassUpdate(GenericObjectFactory gef) {
        // first handle the super classes, ...
        Class superClass = gef.getBaseClass().getSuperclass();
        if (superClass != null && superClass.equals(Object.class) == false) {
            GenericObjectFactory superGef = (GenericObjectFactory) objectMappings.get(superClass);
            if (superGef != null) {
                performSuperClassUpdate(superGef);
            }
        }

        // and finally append all local properties ...
        propertyDefinition.addAll(Arrays.asList(gef.getPropertyDefinitions()));
        attributeDefinition.addAll(Arrays.asList(gef.getAttributeDefinitions()));
        constructorDefinition.addAll(Arrays.asList(gef.getConstructorDefinitions()));
        lookupDefinitions.addAll(Arrays.asList(gef.getLookupDefinitions()));
        orderedNames.addAll(Arrays.asList(gef.getOrderedPropertyNames()));
    }

    /**
     * Starts a object definition. The object definition collects all properties of
     * an bean-class and defines, which constructor should be used when creating the
     * class.
     *
     * @param className the class name of the defined object
     * @param register the (optional) register name, to lookup and reference the object
     * later.
     * 
     * @return true, if the definition was accepted, false otherwise.
     * @throws ObjectDescriptionException if an unexpected error occured.
     */
    protected boolean startObjectDefinition(String className, String register, boolean ignore)
        throws ObjectDescriptionException {

        if (ignore) {
            return false;
        }
        this.target = loadClass(className);
        if (target == null) {
            Log.warn(new Log.SimpleMessage("Failed to load class ", className));
            return false;
        }
        this.registerName = register;
        propertyDefinition = new ArrayList();
        attributeDefinition = new ArrayList();
        constructorDefinition = new ArrayList();
        lookupDefinitions = new ArrayList();
        orderedNames = new ArrayList();
        return true;
    }

    /**
     * Handles an attribute definition. This method gets called after the object definition
     * was started. The method will be called for every defined attribute property.
     *
     * @param name the name of the property
     * @param attribName the xml-attribute name to use later.
     * @param handlerClass the attribute handler class.
     * @throws ObjectDescriptionException if an error occured.
     */
    protected void handleAttributeDefinition(String name, String attribName, String handlerClass)
        throws ObjectDescriptionException {
        AttributeHandler handler = loadAttributeHandler(handlerClass);
        orderedNames.add(name);
        attributeDefinition.add(new AttributeDefinition(name, attribName, handler));
    }

    /**
     * Handles an element definition. This method gets called after the object definition
     * was started. The method will be called for every defined element property. Element
     * properties are used to describe complex objects.
     *
     * @param name the name of the property
     * @param element the xml-tag name for the child element.
     * @throws ObjectDescriptionException if an error occurs.
     */
    protected void handleElementDefinition(String name, String element)
        throws ObjectDescriptionException {
        orderedNames.add(name);
        propertyDefinition.add(new PropertyDefinition(name, element));
    }

    /**
     * Handles an lookup definition. This method gets called after the object definition
     * was started. The method will be called for every defined lookup property. Lookup properties
     * reference previously created object using the object's registry name.
     *
     * @param name the property name of the base object
     * @param lookupKey the register key of the referenced object
     * @throws ObjectDescriptionException if an error occured.
     */
    protected void handleLookupDefinition(String name, String lookupKey)
        throws ObjectDescriptionException {
        LookupDefinition ldef = new LookupDefinition(name, lookupKey);
        orderedNames.add(name);
        lookupDefinitions.add(ldef);
    }

    /**
     * Finializes the object definition.
     *
     * @throws ObjectDescriptionException if an error occures.
     */
    protected void endObjectDefinition()
        throws ObjectDescriptionException {

        final PropertyDefinition[] propertyDefs = (PropertyDefinition[])
            propertyDefinition.toArray(new PropertyDefinition[0]);
        final LookupDefinition[] lookupDefs = (LookupDefinition[])
            lookupDefinitions.toArray(new LookupDefinition[0]);
        final AttributeDefinition[] attribDefs = (AttributeDefinition[])
            attributeDefinition.toArray(new AttributeDefinition[0]);
        final ConstructorDefinition[] constructorDefs = (ConstructorDefinition[])
            constructorDefinition.toArray(new ConstructorDefinition[0]);
        final String[] orderedNamesDefs = (String[])
            orderedNames.toArray(new String[0]);

        GenericObjectFactory objectFactory = new GenericObjectFactory
            (target, registerName, constructorDefs,
                propertyDefs, lookupDefs, attribDefs, orderedNamesDefs);
        objectMappings.put(target, objectFactory);
    }

    /**
     * Handles a constructor definition. Only one constructor can be defined for
     * a certain object type. The constructor will be filled using the given properties.
     *
     * @param propertyName the property name of the referenced local property
     * @param parameterClass the parameter class for the parameter.
     */
    protected void handleConstructorDefinition(String propertyName, String parameterClass) {
        Class c = loadClass(parameterClass);
        orderedNames.add(propertyName);
        constructorDefinition.add(new ConstructorDefinition(propertyName, c));
    }

    /**
     * Handles a manual mapping definition. The manual mapping maps specific
     * read and write handlers to a given base class. Manual mappings always
     * override any other definition.
     *
     * @param className the base class name
     * @param readHandler the class name of the read handler
     * @param writeHandler the class name of the write handler
     * @return true, if the mapping was accepted, false otherwise.
     * @throws ObjectDescriptionException if an unexpected error occured.
     */
    protected boolean handleManualMapping(String className, String readHandler, String writeHandler)
        throws ObjectDescriptionException {

        if (manualMappings.containsKey(className) == false) {
            Class loadedClass = loadClass(className);
            manualMappings.put(loadedClass, new ManualMappingDefinition
                (loadedClass, readHandler, writeHandler));
            return true;
        }
        return false;
    }

    /**
     * Starts a multiplex mapping. Multiplex mappings are used to define polymorphic
     * argument handlers. The mapper will collect all derived classes of the given
     * base class and will select the corresponding mapping based on the given type
     * attribute.
     *
     * @param className the base class name
     * @param typeAttr the xml-attribute name containing the mapping key
     */
    protected void startMultiplexMapping(String className, String typeAttr) {
        this.baseClass = className;
        this.attributeName = typeAttr;
        this.multiplexEntries = new ArrayList();
    }

    /**
     * Defines an entry for the multiplex mapping. The new entry will be activated
     * when the base mappers type attribute contains this <code>typename</code> and
     * will resolve to the handler for the given classname.
     *
     * @param typeName the type value for this mapping.
     * @param className the class name to which this mapping resolves.
     * @throws ObjectDescriptionException if an error occurs.
     */
    protected void handleMultiplexMapping(String typeName, String className)
        throws ObjectDescriptionException {
        multiplexEntries.add
            (new MultiplexMappingEntry(typeName, className));
    }

    /**
     * Finializes the multiplexer mapping.
     *
     * @throws ObjectDescriptionException if an error occurs.
     */
    protected void endMultiplexMapping() throws ObjectDescriptionException {
        MultiplexMappingEntry[] mappings = (MultiplexMappingEntry[])
            multiplexEntries.toArray(new MultiplexMappingEntry[0]);
        Class c = loadClass(baseClass);
        multiplexMappings.put(c,
            new MultiplexMappingDefinition(c, attributeName, mappings));
        multiplexEntries = null;
    }

    /**
     * Loads an instantiates the attribute handler specified by the given
     * class name.
     *
     * @param attribute the attribute handlers classname.
     * @return the created attribute handler instance
     * @throws ObjectDescriptionException if the handler could not be loaded.
     */
    private AttributeHandler loadAttributeHandler(String attribute)
        throws ObjectDescriptionException {

        Class c = loadClass(attribute);
        try {
            return (AttributeHandler) c.newInstance();
        }
        catch (Exception e) {
            throw new ObjectDescriptionException
                ("Invalid attribute handler specified: " + attribute);
        }
    }

    /**
     * Checks, whether the factory has a description for the given class.
     *
     * @param c the class to be handled by the factory.
     * @return true, if an description exists for the given class, false otherwise.
     */
    public boolean isGenericHandler(Class c) {
        return objectMappings.containsKey(c);
    }

    /**
     * Returns a factory instance for the given class. The factory is independent
     * from all previously generated instances.
     *
     * @param c the class
     * @return the object factory.
     */
    public GenericObjectFactory getFactoryForClass(Class c) {
        GenericObjectFactory factory = (GenericObjectFactory) this.objectMappings.get(c);
        if (factory == null) {
            return null;
        }
        return factory.getInstance();
    }

    /**
     * Returns the manual mapping definition for the given class, or null, if
     * not manual definition exists.
     *
     * @param c the class for which to check the existence of the definition
     * @return the manual mapping definition or null.
     */
    public ManualMappingDefinition getManualMappingDefinition(Class c) {
        return (ManualMappingDefinition) manualMappings.get(c);
    }

    /**
     * Returns the multiplex definition for the given class, or null, if no
     * such definition exists.
     *
     * @param c the class for which to check the existence of the multiplexer
     * @return the multiplexer for the class, or null if no multiplexer exists.
     */
    public MultiplexMappingDefinition getMultiplexDefinition(Class c) {
        MultiplexMappingDefinition definition = (MultiplexMappingDefinition)
            multiplexMappings.get(c);
        return definition;
    }

}
