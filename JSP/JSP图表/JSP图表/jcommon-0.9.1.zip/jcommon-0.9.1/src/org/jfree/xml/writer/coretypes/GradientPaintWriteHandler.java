/* ========================================================================
 * JCommon : a free general purpose class library for the Java(tm) platform
 * ========================================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 * 
 * Project Info:  http://www.jfree.org/jcommon/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 * 
 * ------------------------------
 * GradientPaintWriteHandler.java
 * ------------------------------
 * (C)opyright 2003, by Thomas Morgner and Contributors.
 *
 * Original Author:  Thomas Morgner;
 * Contributor(s):   David Gilbert (for Object Refinery Limited);
 *
 * $Id: GradientPaintWriteHandler.java,v 1.5 2004/01/01 23:59:30 mungady Exp $
 *
 * Changes
 * -------
 * 12-Nov-2003 : Initial version (TM);
 * 23-Dec-2003 : Updated header (DG);
 * 
 */

package org.jfree.xml.writer.coretypes;

import java.awt.GradientPaint;
import java.awt.Color;
import java.awt.geom.Point2D;
import java.io.IOException;

import org.jfree.xml.writer.XMLWriter;
import org.jfree.xml.writer.AbstractXmlWriteHandler;
import org.jfree.xml.writer.RootXmlWriteHandler;
import org.jfree.xml.writer.XMLWriterException;

/**
 * A handler for writing {@link GradientPaint} objects.
 */
public class GradientPaintWriteHandler extends AbstractXmlWriteHandler  {

    /**
     * Default constructor.
     */
    public GradientPaintWriteHandler() {
    }

    /**
     * Performs the writing of a single object.
     *
     * @param tagName
     * @param object
     * @param writer
     * @throws IOException
     * @throws XMLWriterException
     */
    public void write(String tagName, Object object, XMLWriter writer,
                      String mPlexAttribute, String mPlexValue)
        throws IOException, XMLWriterException {
        GradientPaint paint = (GradientPaint) object;
        writer.writeTag(tagName, mPlexAttribute, mPlexValue, false);
        writer.startBlock();
        RootXmlWriteHandler rootHandler = getRootHandler();
        rootHandler.write("color1", paint.getColor1(), Color.class, writer);
        writer.allowLineBreak();
        rootHandler.write("color2", paint.getColor2(), Color.class, writer);
        writer.allowLineBreak();
        rootHandler.write("point1", paint.getPoint1(), Point2D.class, writer);
        writer.allowLineBreak();
        rootHandler.write("point2", paint.getPoint2(), Point2D.class, writer);
        writer.endBlock();
        writer.writeCloseTag(tagName);        
    }
}
